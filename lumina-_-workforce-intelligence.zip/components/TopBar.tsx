import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../services/store';
import { Languages, Bell, Search, Menu, Check, Info, X } from 'lucide-react';
import { FacultyMetrics } from '../types';

export const TopBar: React.FC<{onMenuClick: () => void}> = ({onMenuClick}) => {
  const { user, isHindi, toggleLanguage, notifications, markNotificationsAsRead, facultyData } = useApp();
  const [showNotifications, setShowNotifications] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<FacultyMetrics[]>([]);
  const [showSearch, setShowSearch] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Filter notifications for current user
  const myNotifications = notifications.filter(n => n.userId === user?.id);
  const unreadCount = myNotifications.filter(n => !n.read).length;

  // Search Logic
  useEffect(() => {
    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase();
      const results = facultyData.filter(f => 
        f.name.toLowerCase().includes(q) || 
        f.dept.toLowerCase().includes(q) ||
        f.role.toLowerCase().includes(q)
      ).slice(0, 5); // Limit to 5 results
      setSearchResults(results);
      setShowSearch(true);
    } else {
      setSearchResults([]);
      setShowSearch(false);
    }
  }, [searchQuery, facultyData]);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSearch(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleBellClick = () => {
    if (!showNotifications && unreadCount > 0) {
        markNotificationsAsRead();
    }
    setShowNotifications(!showNotifications);
  };

  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b-0 border-white/5 px-6 py-4 flex items-center justify-between md:pl-6">
      <div className="flex items-center gap-4">
        <button onClick={onMenuClick} className="md:hidden text-slate-300 hover:text-white">
            <Menu />
        </button>
        
        {/* Search Bar */}
        <div className="relative hidden md:block group" ref={searchRef}>
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-lumina-muted w-4 h-4 group-focus-within:text-lumina-accent transition-colors" />
            <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => { if(searchQuery) setShowSearch(true); }}
                placeholder="Search faculty, depts..." 
                className="bg-lumina-surface/50 border border-white/10 rounded-full pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-lumina-accent/50 focus:ring-1 focus:ring-lumina-accent/50 w-64 transition-all"
            />
            
            {/* Search Results Dropdown */}
            {showSearch && (
                <div className="absolute top-12 left-0 w-80 glass-card rounded-xl border border-white/10 shadow-2xl overflow-hidden animate-fade-in z-50">
                    {searchResults.length > 0 ? (
                        <>
                            <div className="p-3 border-b border-white/5 bg-white/5">
                                <h4 className="text-xs font-bold text-slate-400 uppercase">Faculty Matches</h4>
                            </div>
                            {searchResults.map((result) => (
                                <div key={result.id} className="p-3 border-b border-white/5 hover:bg-white/10 transition-colors flex items-center gap-3 cursor-pointer last:border-0">
                                    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white shrink-0">
                                        {result.avatar ? <img src={result.avatar} alt={result.name} className="w-full h-full rounded-full object-cover" /> : result.name.charAt(0)}
                                    </div>
                                    <div>
                                        <div className="text-sm font-bold text-white">{result.name}</div>
                                        <div className="text-xs text-slate-400">{result.dept} &bull; <span className="text-lumina-accent">{result.role}</span></div>
                                    </div>
                                </div>
                            ))}
                        </>
                    ) : (
                        <div className="p-4 text-center">
                             <p className="text-sm text-slate-500">No results found.</p>
                        </div>
                    )}
                </div>
            )}
        </div>
      </div>

      <div className="flex items-center gap-6">
        <button 
          onClick={toggleLanguage}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 text-xs font-medium text-lumina-text border border-white/10 transition-colors"
        >
          <Languages size={14} />
          {isHindi ? 'हिन्दी' : 'English'}
        </button>

        <div className="relative" ref={dropdownRef}>
            <button 
                onClick={handleBellClick}
                className={`relative transition-colors ${showNotifications ? 'text-white' : 'text-lumina-muted hover:text-white'}`}
            >
                <Bell size={20} />
                {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-lumina-danger rounded-full border-2 border-lumina-base animate-pulse"></span>
                )}
            </button>

            {/* Notification Dropdown */}
            {showNotifications && (
                <div className="absolute right-0 top-12 w-80 md:w-96 glass-card rounded-2xl border border-white/10 shadow-2xl overflow-hidden animate-fade-in origin-top-right z-50">
                    <div className="p-4 border-b border-white/5 flex justify-between items-center bg-white/5">
                        <h3 className="font-bold text-white text-sm">Notifications</h3>
                        <span className="text-xs text-slate-400">{myNotifications.length} total</span>
                    </div>
                    
                    <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
                        {myNotifications.length === 0 ? (
                            <div className="p-8 text-center text-slate-500 text-sm">
                                <Bell className="mx-auto mb-2 opacity-50" size={24} />
                                No new notifications
                            </div>
                        ) : (
                            myNotifications.map((n) => (
                                <div key={n.id} className={`p-4 border-b border-white/5 hover:bg-white/5 transition-colors flex gap-3 ${!n.read ? 'bg-white/[0.02]' : ''}`}>
                                    <div className={`mt-1 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                                        n.type === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
                                        n.type === 'error' ? 'bg-rose-500/20 text-rose-400' :
                                        'bg-blue-500/20 text-blue-400'
                                    }`}>
                                        {n.type === 'success' ? <Check size={14} /> :
                                         n.type === 'error' ? <X size={14} /> :
                                         <Info size={14} />}
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start mb-1">
                                            <h4 className={`text-sm font-medium ${n.read ? 'text-slate-300' : 'text-white'}`}>{n.title}</h4>
                                            <span className="text-[10px] text-slate-500 whitespace-nowrap ml-2">
                                                {new Date(n.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                            </span>
                                        </div>
                                        <p className="text-xs text-slate-400 leading-relaxed">{n.message}</p>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
        </div>

        <div className="flex items-center gap-3 pl-6 border-l border-white/10">
          <div className="text-right hidden sm:block">
            <div className="text-sm font-display font-semibold text-white">{user?.name}</div>
            <div className="text-xs text-lumina-muted">{user?.role}</div>
          </div>
          <div className="h-10 w-10 rounded-full bg-gradient-to-tr from-lumina-accent to-purple-500 p-[2px]">
            <img 
                src={user?.avatar} 
                alt="Profile" 
                className="rounded-full h-full w-full object-cover border-2 border-lumina-base"
            />
          </div>
        </div>
      </div>
    </header>
  );
};