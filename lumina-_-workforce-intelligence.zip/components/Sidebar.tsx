import React from 'react';
import { useApp, TRANSLATIONS } from '../services/store';
import { 
  LayoutDashboard, 
  Users, 
  BrainCircuit, 
  CalendarDays, 
  LogOut, 
  Settings,
  BellRing,
  AlertOctagon,
  Workflow
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  setPage: (page: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, setPage }) => {
  const { user, logout, isHindi, alerts } = useApp();
  const t = isHindi ? TRANSLATIONS.hi : TRANSLATIONS.en;
  
  const activeAlerts = alerts.filter(a => !a.resolved).length;

  const menuItems = [
    { 
      id: 'dashboard', 
      icon: LayoutDashboard, 
      label: t.dashboard, 
      roles: ['ADMIN', 'HR', 'FACULTY'] 
    },
    { 
      id: 'attendance', 
      icon: Users, 
      label: t.attendance, 
      roles: ['ADMIN', 'HR', 'FACULTY'] 
    },
    { 
      id: 'leaves', 
      icon: CalendarDays, 
      label: t.leaves, 
      roles: ['ADMIN', 'HR', 'FACULTY'] 
    },
    { 
      id: 'workflow', 
      icon: Workflow, 
      label: t.workflow, 
      roles: ['ADMIN', 'HR', 'FACULTY'] 
    },
    { 
      id: 'analytics', 
      icon: BrainCircuit, 
      label: t.analytics, 
      roles: ['ADMIN', 'HR'] // Hidden for Faculty
    },
    { 
      id: 'alerts', 
      icon: AlertOctagon, 
      label: t.alerts, 
      badge: activeAlerts, 
      roles: ['ADMIN', 'HR'] // Hidden for Faculty
    },
    { 
      id: 'settings', 
      icon: Settings, 
      label: t.settings, 
      roles: ['ADMIN', 'HR', 'FACULTY'] 
    },
  ];

  // Filter menu items based on current user role
  const filteredItems = menuItems.filter(item => 
    user?.role && item.roles.includes(user.role)
  );

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-lumina-base border-r border-white/5 flex flex-col z-50 hidden md:flex">
      <div className="p-8 pb-4">
        <h1 className="font-display font-bold text-2xl tracking-tighter text-white flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-lumina-accent flex items-center justify-center">
            <BrainCircuit className="text-lumina-base w-5 h-5" />
          </div>
          LUMINA
        </h1>
        <p className="text-lumina-muted text-xs mt-2 ml-1 tracking-wider uppercase">Workforce Intelligence</p>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2">
        {filteredItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setPage(item.id)}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-300 group ${
              currentPage === item.id 
                ? 'bg-lumina-surface text-lumina-accent shadow-lg shadow-lumina-accent/10' 
                : 'text-lumina-muted hover:text-white hover:bg-white/5'
            }`}
          >
            <div className="flex items-center gap-4">
                <item.icon size={20} className={`transition-transform duration-300 ${currentPage === item.id ? 'scale-110' : 'group-hover:scale-110'}`} />
                <span className="font-medium">{item.label}</span>
            </div>
            {item.badge && item.badge > 0 && (
                <span className="bg-lumina-danger text-white text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse">
                    {item.badge}
                </span>
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-white/5">
        <div className="glass-panel p-4 rounded-xl mb-4">
            <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-lumina-muted font-bold uppercase">System Status</span>
                <span className="w-2 h-2 rounded-full bg-lumina-success animate-pulse"></span>
            </div>
            <div className="text-xs text-slate-400">ML Model: <span className="text-white">v2.4 Online</span></div>
            <div className="text-xs text-slate-400">Latency: <span className="text-white">24ms</span></div>
        </div>

        <button 
          onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-3 text-lumina-danger hover:bg-lumina-danger/10 rounded-xl transition-colors"
        >
          <LogOut size={18} />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </aside>
  );
};
