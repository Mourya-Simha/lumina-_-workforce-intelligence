import React from 'react';
import { useApp } from '../services/store';
import { CheckCircle, AlertCircle, Info, X } from 'lucide-react';

export const ToastContainer = () => {
  const { toasts, removeToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col gap-3 pointer-events-none">
      {toasts.map((toast) => (
        <div 
          key={toast.id} 
          className={`pointer-events-auto flex items-center gap-3 min-w-[300px] p-4 rounded-xl shadow-2xl border-l-4 animate-slide-up backdrop-blur-xl ${
            toast.type === 'success' ? 'bg-lumina-surface/90 border-lumina-success text-white' :
            toast.type === 'error' ? 'bg-lumina-surface/90 border-lumina-danger text-white' :
            'bg-lumina-surface/90 border-lumina-accent text-white'
          }`}
        >
          {toast.type === 'success' && <CheckCircle size={20} className="text-lumina-success" />}
          {toast.type === 'error' && <AlertCircle size={20} className="text-lumina-danger" />}
          {toast.type === 'info' && <Info size={20} className="text-lumina-accent" />}
          
          <p className="text-sm font-medium flex-1">{toast.message}</p>
          
          <button 
            onClick={() => removeToast(toast.id)}
            className="text-white/50 hover:text-white transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      ))}
    </div>
  );
};
