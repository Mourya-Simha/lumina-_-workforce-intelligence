import { FacultyMetrics, AttendanceRecord, LeaveRequest, Alert, DEPARTMENTS, DailyStats, Badge, ScheduleEvent } from '../types';

// UTILS
const seededRandom = (seed: number) => {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
};

const randomDate = (start: Date, end: Date) => {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
};

// --- DATA GENERATORS ---

export const generateFaculty = (count: number = 100): FacultyMetrics[] => {
  const faculty: FacultyMetrics[] = [];
  const firstNames = ['Aarav', 'Vivaan', 'Aditya', 'Vihaan', 'Arjun', 'Sai', 'Reyansh', 'Ayaan', 'Krishna', 'Ishaan', 'Diya', 'Saanvi', 'Anaya', 'Aadhya', 'Pari', 'Anvi', 'Myra', 'Sarah', 'David', 'Robert'];
  const lastNames = ['Patel', 'Sharma', 'Singh', 'Kumar', 'Gupta', 'Verma', 'Mishra', 'Reddy', 'Nair', 'Kapoor', 'Khan', 'Chatterjee', 'Iyer', 'Das', 'Rivera'];
  const possibleSkills = ['Machine Learning', 'Data Structures', 'Thermodynamics', 'Fluid Mechanics', 'Calculus', 'Quantum Physics', 'Digital Logic', 'VLSI'];

  for (let i = 0; i < count; i++) {
    const seed = i * 137;
    const dept = DEPARTMENTS[Math.floor(seededRandom(seed) * DEPARTMENTS.length)];
    const attRate = 65 + Math.floor(seededRandom(seed + 1) * 35); // 65-100%
    const workload = 15 + Math.floor(seededRandom(seed + 2) * 45); // 15-60 hrs
    const teachingLoadScore = Math.floor(seededRandom(seed + 4) * 10); // 0-10 stress
    const leaves = Math.floor(seededRandom(seed + 3) * 20);
    
    // ML Logic: Burnout Score Calculation
    let burnout = 0;
    if (workload > 40) burnout += 30;
    if (workload > 50) burnout += 20;
    if (attRate < 80) burnout += 15;
    if (leaves < 5) burnout += 15; // No breaks
    if (teachingLoadScore > 8) burnout += 10;
    burnout += Math.floor(seededRandom(seed + 5) * 20); // Random stress
    burnout = Math.min(100, Math.max(0, burnout));

    let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' = 'LOW';
    if (burnout > 75) riskLevel = 'HIGH';
    else if (burnout > 50) riskLevel = 'MEDIUM';

    // Gamification Badges
    const badges: Badge[] = [];
    if (attRate > 95) badges.push({ id: 'b1', name: 'Punctuality Pro', icon: 'Clock', description: '95%+ Attendance', dateEarned: '2023-09-01', type: 'PUNCTUALITY' });
    if (burnout < 30) badges.push({ id: 'b2', name: 'Zen Master', icon: 'Leaf', description: 'Maintained low stress levels', dateEarned: '2023-10-01', type: 'WELLNESS' });

    // Assign skills based on Dept (Generic for now)
    const skills = [possibleSkills[Math.floor(seededRandom(seed) * possibleSkills.length)], 'Teaching', 'Research'];

    faculty.push({
      id: `FAC-${1000 + i}`,
      name: `Dr. ${firstNames[i % firstNames.length]} ${lastNames[i % lastNames.length]}`,
      email: `faculty.${1000 + i}@lumina.edu`,
      dept,
      role: 'FACULTY',
      attendanceRate: attRate,
      burnoutScore: burnout,
      workloadHours: workload,
      teachingLoadScore,
      leavesTaken: leaves,
      leaveBalance: {
        CL: 10 - Math.floor(leaves * 0.5),
        SL: 7 - Math.floor(leaves * 0.3),
        EL: 30 - Math.floor(leaves * 0.2)
      },
      lastPresent: new Date().toISOString(),
      riskLevel,
      skills,
      joinedAt: '2020-01-15',
      badges
    });
  }
  return faculty;
};

// Generate historical data for charts
export const generateDailyStats = (): DailyStats[] => {
  const stats: DailyStats[] = [];
  const today = new Date();
  
  for (let i = 30; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const isWeekend = d.getDay() === 0 || d.getDay() === 6;
    
    // Pattern: Lower attendance on Mondays/Fridays
    let basePresent = isWeekend ? 0 : (85 + Math.random() * 10);
    if (d.getDay() === 5) basePresent -= 5; // Friday dip

    stats.push({
      date: d.toISOString().split('T')[0],
      totalPresent: Math.floor(basePresent),
      totalAbsent: isWeekend ? 0 : (100 - Math.floor(basePresent)),
      predictedShortage: !isWeekend && basePresent < 80
    });
  }
  return stats;
};

export const getDepartmentStats = (faculty: FacultyMetrics[]) => {
  const stats: { [key: string]: { totalAtt: number, count: number } } = {};
  
  faculty.forEach(f => {
    if (!stats[f.dept]) {
      stats[f.dept] = { totalAtt: 0, count: 0 };
    }
    stats[f.dept].totalAtt += f.attendanceRate;
    stats[f.dept].count += 1;
  });

  return Object.keys(stats).map(dept => ({
    dept,
    attendance: Math.round(stats[dept].totalAtt / stats[dept].count)
  }));
};

// --- SCHEDULE GENERATOR (WORKFLOW) ---
export const generateSchedule = (facultyId: string): ScheduleEvent[] => {
    // Deterministic random based on ID
    const numId = parseInt(facultyId.replace('FAC-', '')) || 1000;
    const seed = numId * 0.123;
    const events: ScheduleEvent[] = [];
    
    // Base schedule for "Today"
    const startTimes = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'];
    const types: ('LECTURE' | 'LAB' | 'RESEARCH' | 'ADMIN')[] = ['LECTURE', 'LECTURE', 'LAB', 'RESEARCH', 'ADMIN'];
    
    // Generate 3-5 events per day
    const eventCount = 3 + Math.floor(seededRandom(seed) * 3);
    
    for(let i=0; i<eventCount; i++) {
        const timeIndex = Math.floor(seededRandom(seed + i) * startTimes.length);
        const type = types[Math.floor(seededRandom(seed + i + 1) * types.length)];
        const start = startTimes[timeIndex];
        // Simple next hour end time
        const hour = parseInt(start.split(':')[0]);
        const end = `${hour + (type === 'LAB' ? 2 : 1)}:00`;
        
        events.push({
            id: `SCH-${facultyId}-${i}`,
            facultyId,
            day: 'Today',
            startTime: start,
            endTime: end,
            title: type === 'LECTURE' ? `Lecture: ${seededRandom(seed+i) > 0.5 ? 'Advanced' : 'Intro to'} Subject` : type,
            type: type,
            location: type === 'LECTURE' ? `Room ${300 + Math.floor(seededRandom(seed+i)*20)}` : 'Main Block'
        });
    }
    
    return events.sort((a, b) => parseInt(a.startTime) - parseInt(b.startTime));
};

// --- SIMULATED ML INTELLIGENCE ---

export const detectAnomalies = (faculty: FacultyMetrics[]): Alert[] => {
  const alerts: Alert[] = [];
  
  // 1. Burnout Detection
  const highRisk = faculty.filter(f => f.burnoutScore > 80);
  highRisk.forEach(f => {
    alerts.push({
      id: `ALT-B-${f.id}`,
      type: 'BURNOUT',
      severity: 'HIGH',
      message: `High burnout risk detected for ${f.name} (${f.burnoutScore}/100). Consecutive workload spikes.`,
      messageHi: `${f.name} के लिए उच्च बर्नआउट जोखिम का पता चला (${f.burnoutScore}/100)। लगातार काम का बोझ बढ़ रहा है।`,
      facultyId: f.id,
      dept: f.dept,
      timestamp: new Date().toISOString(),
      resolved: false
    });
  });

  // 2. Attendance Anomalies (Z-Score simulation)
  const lowAtt = faculty.filter(f => f.attendanceRate < 70);
  lowAtt.forEach(f => {
    alerts.push({
      id: `ALT-A-${f.id}`,
      type: 'ANOMALY',
      severity: 'MEDIUM',
      message: `${f.name} has dropped 20% below dept average attendance this month.`,
      messageHi: `${f.name} की उपस्थिति इस महीने विभाग के औसत से 20% कम हो गई है।`,
      facultyId: f.id,
      dept: f.dept,
      timestamp: new Date().toISOString(),
      resolved: false
    });
  });

  return alerts;
};

export const checkLeaveClustering = (requests: LeaveRequest[]): Alert[] => {
  const alerts: Alert[] = [];
  const deptCounts: {[key: string]: number} = {};
  
  // Count approved/pending leaves per dept
  requests.forEach(r => {
    if (r.status !== 'Rejected') {
      deptCounts[r.dept] = (deptCounts[r.dept] || 0) + 1;
    }
  });

  Object.entries(deptCounts).forEach(([dept, count]) => {
    if (count >= 3) {
      alerts.push({
        id: `ALT-C-${dept}`,
        type: 'CLUSTERING',
        severity: 'CRITICAL',
        message: `Potential shortage in ${dept}: ${count} faculty members on leave simultaneously next week.`,
        messageHi: `${dept} में संभावित कमी: अगले सप्ताह ${count} संकाय सदस्य एक साथ छुट्टी पर हैं।`,
        dept,
        timestamp: new Date().toISOString(),
        resolved: false
      });
    }
  });

  return alerts;
};

// --- NLQ ENGINE (SIMULATED) ---
export const processNLQ = (query: string, faculty: FacultyMetrics[]): { type: string, data: any, answer: string } => {
  const q = query.toLowerCase();
  
  if (q.includes('burnout') || q.includes('risk')) {
    const risky = faculty.filter(f => f.burnoutScore > 75).slice(0, 5);
    return {
      type: 'list',
      data: risky,
      answer: `Found ${risky.length} faculty members with high burnout risk (>75). Top concern: ${risky[0]?.name}.`
    };
  }
  
  if (q.includes('attendance') || q.includes('absent')) {
    const avg = faculty.reduce((acc, curr) => acc + curr.attendanceRate, 0) / faculty.length;
    return {
      type: 'stat',
      data: avg,
      answer: `The average attendance rate across all departments is ${avg.toFixed(1)}%. CS Department is slightly below average.`
    };
  }

  if (q.includes('leave') || q.includes('vacation')) {
     return {
         type: 'text',
         data: null,
         answer: "Based on clustering analysis, avoid approving leaves in Computer Science for Oct 12-15 due to high volume."
     };
  }

  if (q.includes('shortage') || q.includes('exam')) {
    return {
        type: 'text',
        data: null,
        answer: "Simulating Exam Scenario: If 15% of faculty take leave during mid-terms, the Physics and Math departments will face critical staffing shortages."
    };
  }

  return {
    type: 'text',
    data: null,
    answer: "I can verify attendance trends, burnout scores, and leave clustering. Try asking 'Show high burnout risks'."
  };
};

// MOCK INITIAL LEAVES
export const mockInitialLeaves: LeaveRequest[] = [
  { id: 'LR-1', facultyId: 'FAC-1001', facultyName: 'Dr. Sarah Connor', dept: 'Computer Science', startDate: '2023-10-12', endDate: '2023-10-15', type: 'SL', status: 'Pending', reason: 'Flu symptoms' },
  { id: 'LR-2', facultyId: 'FAC-1045', facultyName: 'Dr. Alan Grant', dept: 'Computer Science', startDate: '2023-10-13', endDate: '2023-10-14', type: 'CL', status: 'Pending', reason: 'Family emergency' },
  { id: 'LR-3', facultyId: 'FAC-1012', facultyName: 'Dr. Ian Malcolm', dept: 'Computer Science', startDate: '2023-10-12', endDate: '2023-10-16', type: 'OD', status: 'Approved', reason: 'Conference' },
  { id: 'LR-4', facultyId: 'FAC-1088', facultyName: 'Dr. Ellie Sattler', dept: 'Biology', startDate: '2023-11-01', endDate: '2023-11-05', type: 'EL', status: 'Approved', reason: 'Research' },
];