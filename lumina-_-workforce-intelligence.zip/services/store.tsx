import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, FacultyMetrics, AttendanceRecord, Alert, LeaveRequest, DailyStats, Toast, Notification } from '../types';
import { generateFaculty, generateDailyStats, detectAnomalies, checkLeaveClustering, mockInitialLeaves } from './dataService';

interface AppContextType {
  user: User | null;
  login: (role: User['role']) => void;
  logout: () => void;
  facultyData: FacultyMetrics[];
  dailyStats: DailyStats[];
  leaves: LeaveRequest[];
  alerts: Alert[];
  isHindi: boolean;
  toggleLanguage: () => void;
  isLoading: boolean;
  addLeaveRequest: (req: LeaveRequest) => void;
  updateLeaveStatus: (id: string, status: 'Approved' | 'Rejected') => void;
  resolveAlert: (id: string) => void;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  notifications: Notification[];
  markNotificationsAsRead: () => void;
  updateUserProfile: (data: { email?: string; id?: string; name?: string; dept?: string; avatar?: string }) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [facultyData, setFacultyData] = useState<FacultyMetrics[]>([]);
  const [dailyStats, setDailyStats] = useState<DailyStats[]>([]);
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [isHindi, setIsHindi] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Initialize Data
  useEffect(() => {
    const data = generateFaculty(100);
    const stats = generateDailyStats();
    
    // Run AI Models
    const anomalyAlerts = detectAnomalies(data);
    const clusteringAlerts = checkLeaveClustering(mockInitialLeaves);
    
    setFacultyData(data);
    setDailyStats(stats);
    setLeaves(mockInitialLeaves);
    setAlerts([...anomalyAlerts, ...clusteringAlerts]);

    // Initial Mock Notifications
    setNotifications([
      {
        id: 'NOT-1',
        userId: 'FAC-1001',
        title: 'System Update',
        message: 'Lumina v2.4 is now live with enhanced burnout prediction.',
        type: 'info',
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        read: false
      }
    ]);
  }, []);

  const login = (role: User['role']) => {
    setIsLoading(true);
    // Simulate API Delay
    setTimeout(() => {
      // Simulate distinct identities for better demo flow
      let mockUser: User;
      
      if (role === 'ADMIN') {
        mockUser = {
            id: 'ADM-001',
            name: 'Alex Rivera',
            email: 'alex.rivera@lumina.edu',
            role: 'ADMIN',
            dept: 'Administration',
            avatar: 'https://i.pravatar.cc/150?u=alex',
        };
      } else if (role === 'HR') {
        mockUser = {
            id: 'HR-001',
            name: 'Jamie Smith',
            email: 'jamie.smith@lumina.edu',
            role: 'HR',
            dept: 'Human Resources',
            avatar: 'https://i.pravatar.cc/150?u=jamie',
        };
      } else {
        // Log in as the specific faculty member used in mockInitialLeaves
        mockUser = {
            id: 'FAC-1001',
            name: 'Dr. Sarah Connor',
            email: 'sarah.connor@lumina.edu',
            role: 'FACULTY',
            dept: 'Computer Science',
            avatar: 'https://i.pravatar.cc/150?u=sarah',
        };
      }

      setUser({
        ...mockUser,
        preferences: {
            language: 'en',
            notifications: true,
            darkMode: true
        }
      });
      setIsLoading(false);
    }, 1200);
  };

  const logout = () => setUser(null);
  const toggleLanguage = () => setIsHindi(prev => !prev);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now().toString() + Math.random().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    
    // Auto-dismiss
    setTimeout(() => {
        removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const addLeaveRequest = (req: LeaveRequest) => {
    setLeaves(prev => [req, ...prev]);
    showToast("Leave request submitted successfully", "success");
    
    // Re-run clustering check
    const newAlerts = checkLeaveClustering([req, ...leaves]);
    if (newAlerts.length > 0) {
        setAlerts(prev => {
            const existingIds = new Set(prev.map(a => a.id));
            const uniqueNew = newAlerts.filter(a => !existingIds.has(a.id));
            return [...uniqueNew, ...prev];
        });
    }
  };

  const updateLeaveStatus = (id: string, status: 'Approved' | 'Rejected') => {
    setLeaves(prev => prev.map(l => {
      if (l.id === id) {
        // Generate notification for the faculty member
        const newNotification: Notification = {
          id: `NOT-${Date.now()}`,
          userId: l.facultyId,
          title: `Leave Request ${status}`,
          message: `Your leave request for ${l.startDate} has been ${status.toLowerCase()}.`,
          type: status === 'Approved' ? 'success' : 'error',
          timestamp: new Date().toISOString(),
          read: false
        };
        setNotifications(prevN => [newNotification, ...prevN]);
        return { ...l, status };
      }
      return l;
    }));
    showToast(`Request ${status} successfully`, status === 'Approved' ? 'success' : 'info');
  };

  const resolveAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, resolved: true } : a));
    showToast("Alert marked as resolved", "success");
  };

  const markNotificationsAsRead = () => {
    if (!user) return;
    setNotifications(prev => prev.map(n => 
        n.userId === user.id ? { ...n, read: true } : n
    ));
  };

  const updateUserProfile = (data: { email?: string; id?: string; name?: string; dept?: string; avatar?: string }) => {
    if (!user) return;
    
    const oldId = user.id;
    const newId = data.id || oldId;
    
    // 1. Update User State
    const updatedUser = { ...user, ...data };
    setUser(updatedUser);

    // 2. Update Faculty Data list (Simulated DB)
    setFacultyData(prev => prev.map(f => 
        f.id === oldId 
            ? { ...f, ...data, id: newId, email: data.email || f.email, name: data.name || f.name, dept: data.dept || f.dept, avatar: data.avatar || f.avatar } 
            : f
    ));

    // 3. Update Foreign Keys if ID changed (to keep leaves/alerts linked to this user)
    if (newId !== oldId) {
        // Update Leaves
        setLeaves(prev => prev.map(l => l.facultyId === oldId ? { ...l, facultyId: newId, facultyName: data.name || l.facultyName } : l));
        
        // Update Alerts
        setAlerts(prev => prev.map(a => a.facultyId === oldId ? { ...a, facultyId: newId } : a));
        
        // Update Notifications
        setNotifications(prev => prev.map(n => n.userId === oldId ? { ...n, userId: newId } : n));
    }

    showToast("Profile updated successfully", "success");
  };

  return (
    <AppContext.Provider value={{ 
        user, login, logout, 
        facultyData, dailyStats, leaves, alerts, 
        isHindi, toggleLanguage, isLoading,
        addLeaveRequest, updateLeaveStatus, resolveAlert,
        toasts, showToast, removeToast,
        notifications, markNotificationsAsRead,
        updateUserProfile
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};

export const TRANSLATIONS = {
  en: {
    dashboard: "Dashboard",
    attendance: "Attendance",
    analytics: "Intelligence",
    leaves: "Leave Mgmt",
    alerts: "Alerts",
    settings: "Settings",
    burnoutRisk: "Burnout Risk",
    predictedShortage: "Predicted Shortage",
    welcome: "Welcome back,",
    today: "Today's Overview",
    risk_high: "CRITICAL",
    risk_med: "MONITOR",
    risk_low: "OPTIMAL",
    shortage_warn: "High Risk Detected",
    nlq_placeholder: "Ask AI: 'Show burnout risks in CS dept'...",
    submit_leave: "Submit Request",
    avgAttendance: "Avg Attendance",
    workflow: "Workflow",
    workflowTitle: "Academic Workflow",
    workflowDesc: "Manage your daily timetable and classes.",
    workflowDescAdmin: "Manage and compare faculty schedules.",
    compare: "Compare Faculty",
    exitCompare: "Exit Comparison",
    facultyA: "Faculty A",
    facultyB: "Faculty B",
    selectFaculty: "Select Faculty...",
    eventsToday: "Events Today",
    noEvents: "No events scheduled.",
    noWorkflow: "No schedule workflow generated for today.",
    editSchedule: "Edit Schedule",
    eventTitle: "Event Title",
    startTime: "Start Time",
    endTime: "End Time",
    eventType: "Type",
    location: "Location",
    cancel: "Cancel",
    saveChanges: "Save Changes",
    searchFaculty: "Search faculty...",
    all: "All",
    lecture: "Lecture",
    lab: "Lab",
    research: "Research",
    admin: "Admin",
    vs: "VS"
  },
  hi: {
    dashboard: "डैशबोर्ड",
    attendance: "उपस्थिति",
    analytics: "बुद्धिमत्ता (Intelligence)",
    leaves: "छुट्टी प्रबंधन",
    alerts: "चेतावनी",
    settings: "सेटिंग्स",
    burnoutRisk: "बर्नआउट जोखिम",
    predictedShortage: "अनुमानित कमी",
    welcome: "वापसी पर स्वागत है,",
    today: "आज का अवलोकन",
    risk_high: "गंभीर",
    risk_med: "निगरानी",
    risk_low: "इष्टतम",
    shortage_warn: "उच्च जोखिम",
    nlq_placeholder: "AI से पूछें: 'CS विभाग में बर्नआउट जोखिम दिखाएं'...",
    submit_leave: "अनुरोध भेजें",
    avgAttendance: "औसत उपस्थिति",
    workflow: "कार्यप्रवाह",
    workflowTitle: "शैक्षणिक कार्यप्रवाह",
    workflowDesc: "अपनी दैनिक समय सारिणी और कक्षाओं का प्रबंधन करें।",
    workflowDescAdmin: "संकाय कार्यक्रम का प्रबंधन और तुलना करें।",
    compare: "संकाय तुलना करें",
    exitCompare: "तुलना से बाहर निकलें",
    facultyA: "संकाय A",
    facultyB: "संकाय B",
    selectFaculty: "संकाय चुनें...",
    eventsToday: "आज के कार्यक्रम",
    noEvents: "कोई कार्यक्रम निर्धारित नहीं है।",
    noWorkflow: "आज के लिए कोई कार्यप्रवाह उत्पन्न नहीं हुआ।",
    editSchedule: "अनुसूची संपादित करें",
    eventTitle: "कार्यक्रम का शीर्षक",
    startTime: "प्रारंभ समय",
    endTime: "समाप्ति समय",
    eventType: "प्रकार",
    location: "स्थान",
    cancel: "रद्द करें",
    saveChanges: "परिवर्तन सहेजें",
    searchFaculty: "संकाय खोजें...",
    all: "सभी",
    lecture: "व्याख्यान",
    lab: "प्रयोगशाला",
    research: "अनुसंधान",
    admin: "प्रशासन",
    vs: "बनाम"
  }
};