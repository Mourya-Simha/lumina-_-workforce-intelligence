# Smart Workforce Analytics & Leave Intelligence Platform (Lumina)

A hackathon-ready, AI-driven platform for university faculty attendance and leave management.

## 🚀 Features

- **Role-Based Dashboards**: Admin, HR, and Faculty views.
- **Predictive Analytics**: Forecasting shortages using historical data.
- **Burnout Detection**: ML-rule based engine to flag high-risk faculty.
- **Leave Clustering**: Automatically detects if too many faculty from one dept are on leave.
- **Natural Language Query (NLQ)**: "Ask" the data questions in plain English.
- **Real-time Alerts**: Notifications for critical shortages or anomalies.

## 🛠 Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS, Shadcn/UI concepts
- **Visualization**: Recharts
- **State**: React Context
- **Deployment**: Vercel

## 🏃‍♂️ Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Run Locally**
   ```bash
   npm run dev
   ```

3. **Deploy**
   - Push to GitHub
   - Import to Vercel
   - Build command: `npm run build`
   - Output dir: `dist`

## 📂 Project Structure

- `/services`: Core logic and mocked backend data.
- `/pages`: Application routes.
- `/components`: Reusable UI components.

## 🔗 Repository

[https://github.com/Mourya-Simha/lumina-workforce](https://github.com/Mourya-Simha/lumina-workforce)
