import React from 'react';
import { useApp, TRANSLATIONS } from '../services/store';
import { getDepartmentStats } from '../services/dataService';
import { TrendingUp, Users, AlertTriangle, ShieldCheck, Calendar, CheckCircle, Zap, Trophy, ArrowRight, BrainCircuit } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { facultyData, isHindi, dailyStats, user, alerts, leaves } = useApp();
  const t = isHindi ? TRANSLATIONS.hi : TRANSLATIONS.en;

  // METRICS CALCULATION
  const totalFaculty = facultyData.length;
  const highRiskCount = facultyData.filter(f => f.riskLevel === 'HIGH').length;
  const deptStats = getDepartmentStats(facultyData);
  
  // Sort depts by attendance for leaderboard
  const topDepts = [...deptStats].sort((a,b) => b.attendance - a.attendance);
  const avgAttendance = Math.round(facultyData.reduce((acc, curr) => acc + curr.attendanceRate, 0) / totalFaculty);
  const pendingLeaves = leaves.filter(l => l.status === 'Pending').length;
  
  // Active alerts
  const activeAlerts = alerts.filter(a => !a.resolved).slice(0, 3);

  const StatCard = ({ title, value, sub, icon: Icon, color, delay }: any) => (
    <div 
        className="glass-card p-6 rounded-2xl relative overflow-hidden group hover:-translate-y-1 transition-all duration-300 opacity-0 animate-slide-up"
        style={{ animationDelay: `${delay}ms` }}
    >
      <div className={`absolute top-0 right-0 p-32 opacity-[0.03] -mr-10 -mt-10 rounded-full bg-${color}-500 group-hover:scale-125 transition-transform duration-700`}></div>
      <div className="flex justify-between items-start mb-4 relative z-10">
        <div className={`p-3 rounded-xl bg-${color}-500/10 text-${color}-400`}>
          <Icon size={24} />
        </div>
        {title === 'High Risk Faculty' && (
            <span className="flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
            </span>
        )}
      </div>
      <div className="relative z-10">
        <h3 className="text-lumina-muted text-sm font-medium mb-1">{title}</h3>
        <div className="text-3xl font-display font-bold text-white mb-1">{value}</div>
        <div className="text-xs text-slate-400">{sub}</div>
      </div>
    </div>
  );

  return (
    <div className="space-y-8 pb-12">
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 animate-fade-in">
        <div>
            <h2 className="text-3xl font-display font-bold text-white mb-2">{t.welcome} {user?.name.split(' ')[0]}</h2>
            <p className="text-lumina-muted">{t.today} &bull; {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</p>
        </div>
        <div className="flex gap-3">
             <div className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2">
                <ShieldCheck size={16} className="text-emerald-400" />
                <span className="text-sm font-medium text-slate-300">Role: <span className="text-white uppercase">{user?.role}</span></span>
             </div>
        </div>
      </div>

      {/* KPI GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard 
            title="Total Faculty" 
            value={totalFaculty} 
            sub="Across 7 Departments" 
            icon={Users} 
            color="blue" 
            delay={100} 
          />
          <StatCard 
            title="Avg Attendance" 
            value={`${avgAttendance}%`} 
            sub="+2.4% from last week" 
            icon={TrendingUp} 
            color="emerald" 
            delay={200} 
          />
          <StatCard 
            title="High Risk Faculty" 
            value={highRiskCount} 
            sub="Burnout indicators detected" 
            icon={AlertTriangle} 
            color="rose" 
            delay={300} 
          />
          <StatCard 
            title="Pending Leaves" 
            value={pendingLeaves} 
            sub="Requires Approval" 
            icon={Calendar} 
            color="amber" 
            delay={400} 
          />
      </div>

      {/* CHARTS ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-slide-up" style={{ animationDelay: '500ms' }}>
          
          {/* Department Leaderboard */}
          <div className="lg:col-span-2 glass-card p-6 rounded-2xl border border-white/10">
              <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <Trophy size={18} className="text-yellow-500" />
                        Department Leaderboard
                    </h3>
                    <p className="text-xs text-slate-400">Average attendance by department</p>
                  </div>
              </div>
              <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={topDepts} layout="vertical" margin={{ left: 20 }}>
                        <XAxis type="number" hide domain={[0, 100]} />
                        <YAxis dataKey="dept" type="category" width={100} tick={{ fill: '#94a3b8', fontSize: 11 }} tickLine={false} axisLine={false} />
                        <Tooltip 
                            cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                        />
                        <Bar dataKey="attendance" radius={[0, 4, 4, 0]} barSize={20}>
                            {topDepts.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : index === topDepts.length - 1 ? '#f43f5e' : '#06b6d4'} />
                            ))}
                        </Bar>
                    </BarChart>
                  </ResponsiveContainer>
              </div>
          </div>

          {/* Quick Alerts */}
          <div className="glass-card p-6 rounded-2xl border border-white/10 flex flex-col">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Zap size={18} className="text-amber-400" />
                  Recent Alerts
              </h3>
              <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-2">
                  {activeAlerts.length > 0 ? (
                      activeAlerts.map(alert => (
                          <div key={alert.id} className="p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
                              <div className="flex justify-between items-start mb-1">
                                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                      alert.severity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                                  }`}>
                                      {alert.severity}
                                  </span>
                                  <span className="text-[10px] text-slate-500">{new Date(alert.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                              </div>
                              <p className="text-xs text-slate-300 leading-snug">{alert.message}</p>
                          </div>
                      ))
                  ) : (
                      <div className="flex flex-col items-center justify-center h-full text-slate-500">
                          <CheckCircle size={32} className="mb-2 opacity-20" />
                          <p className="text-xs">All systems nominal</p>
                      </div>
                  )}
              </div>
              <button 
                onClick={() => onNavigate('alerts')}
                className="mt-4 w-full py-2 bg-white/5 hover:bg-white/10 rounded-lg text-xs font-bold text-slate-400 hover:text-white transition-colors flex items-center justify-center gap-2"
              >
                  View All Alerts <ArrowRight size={12} />
              </button>
          </div>
      </div>

      {/* Comparison Access */}
      {(user?.role === 'ADMIN' || user?.role === 'HR') && (
          <div 
            className="glass-card p-8 rounded-2xl border border-lumina-accent/20 bg-gradient-to-r from-lumina-surface via-indigo-950/20 to-lumina-accent/5 animate-slide-up relative overflow-hidden group" 
            style={{ animationDelay: '600ms' }}
          >
              <div className="absolute right-0 top-0 h-full w-64 bg-gradient-to-l from-lumina-accent/10 to-transparent skew-x-12 translate-x-12 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
              
              <div className="flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
                  <div>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-lumina-accent/20 rounded-lg text-lumina-accent">
                            <BrainCircuit size={24} />
                        </div>
                        <h3 className="text-xl font-bold text-white">Deep-Dive Intelligence</h3>
                      </div>
                      <p className="text-slate-400 text-sm max-w-xl">
                          Leverage AI to compare faculty performance metrics, analyze department benchmarks, and simulate workforce scenarios with our advanced engine.
                      </p>
                  </div>
                  <div className="flex gap-3">
                      <button 
                        onClick={() => onNavigate('analytics')}
                        className="px-6 py-3 rounded-xl bg-lumina-accent text-lumina-base font-bold hover:bg-cyan-300 transition-all hover:scale-105 shadow-lg shadow-cyan-900/20 flex items-center gap-2"
                      >
                          Launch Analytics Engine <ArrowRight size={18} />
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
