import React, { useState } from 'react';
import { useApp } from '../services/store';
import { AlertTriangle, CheckCircle, ShieldAlert, Filter } from 'lucide-react';

export const Alerts = () => {
  const { alerts, resolveAlert } = useApp();
  const [filter, setFilter] = useState('ALL');

  const filteredAlerts = alerts.filter(a => {
    if (filter === 'ALL') return true;
    if (filter === 'ACTIVE') return !a.resolved;
    return a.type === filter;
  });

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-display font-bold text-white">System Alerts</h2>
        <div className="flex gap-2">
            {['ALL', 'ACTIVE', 'SHORTAGE', 'BURNOUT'].map(f => (
                <button 
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border ${
                        filter === f 
                        ? 'bg-white/10 border-white/20 text-white' 
                        : 'border-transparent text-slate-500 hover:text-slate-300'
                    }`}
                >
                    {f}
                </button>
            ))}
        </div>
      </div>

      <div className="space-y-4">
          {filteredAlerts.map((alert, i) => (
              <div 
                key={alert.id}
                className={`flex flex-col md:flex-row gap-6 p-6 rounded-2xl border transition-all ${
                    alert.resolved 
                    ? 'bg-white/5 border-white/5 opacity-50' 
                    : 'glass-card border-white/10'
                }`}
              >
                  <div className="flex items-start gap-4 flex-1">
                      <div className={`p-3 rounded-full ${
                          alert.severity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-500' :
                          alert.severity === 'HIGH' ? 'bg-orange-500/20 text-orange-500' :
                          'bg-yellow-500/20 text-yellow-500'
                      }`}>
                          <AlertTriangle size={24} />
                      </div>
                      <div>
                          <div className="flex items-center gap-2 mb-1">
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                                  alert.severity === 'CRITICAL' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' :
                                  'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
                              }`}>{alert.severity}</span>
                              <span className="text-xs text-slate-500 uppercase tracking-wider">{alert.type}</span>
                              <span className="text-xs text-slate-600">&bull; {new Date(alert.timestamp).toLocaleString()}</span>
                          </div>
                          <h4 className="text-lg font-bold text-white mb-1">{alert.message}</h4>
                          <p className="text-sm text-slate-400">Department: {alert.dept}</p>
                      </div>
                  </div>

                  <div className="flex items-center gap-4 border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-6">
                      {!alert.resolved ? (
                          <button 
                            onClick={() => resolveAlert(alert.id)}
                            className="px-6 py-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold text-sm hover:bg-emerald-500/20 transition-colors flex items-center gap-2"
                          >
                              <CheckCircle size={16} /> Mark Resolved
                          </button>
                      ) : (
                          <div className="text-emerald-500 font-bold text-sm flex items-center gap-2">
                              <CheckCircle size={16} /> Resolved
                          </div>
                      )}
                  </div>
              </div>
          ))}
          {filteredAlerts.length === 0 && (
              <div className="text-center py-20">
                  <ShieldAlert size={48} className="mx-auto text-slate-600 mb-4" />
                  <p className="text-slate-500">No alerts found matching your filter.</p>
              </div>
          )}
      </div>
    </div>
  );
};
