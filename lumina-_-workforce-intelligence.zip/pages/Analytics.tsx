import React, { useState, useEffect } from 'react';
import { useApp, TRANSLATIONS } from '../services/store';
import { processNLQ } from '../services/dataService';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, BarChart, Bar, Legend, Cell } from 'recharts';
import { Sparkles, MessageSquare, Send, Mic, Eye, EyeOff, Sliders, User, Building2, TrendingUp, TrendingDown, Scale, Activity } from 'lucide-react';
import { DEPARTMENTS } from '../types';

export const Analytics = () => {
  const { facultyData, dailyStats, isHindi } = useApp();
  const t = isHindi ? TRANSLATIONS.hi : TRANSLATIONS.en;
  
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'COMPARISON' | 'SIMULATOR' | 'NLQ'>('OVERVIEW');
  const [nlqQuery, setNlqQuery] = useState('');
  const [nlqResult, setNlqResult] = useState<{type: string, answer: string, data: any} | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [privacyMode, setPrivacyMode] = useState(false);

  // Simulator State
  const [simLeavePercent, setSimLeavePercent] = useState(15);
  const [simDept, setSimDept] = useState('Computer Science');

  // Comparison State
  const [compMode, setCompMode] = useState<'DEPT' | 'FACULTY'>('DEPT');
  const [selectedDeptA, setSelectedDeptA] = useState(DEPARTMENTS[0]);
  const [selectedDeptB, setSelectedDeptB] = useState(DEPARTMENTS[1]);
  const [selectedFacAId, setSelectedFacAId] = useState('');
  const [selectedFacBId, setSelectedFacBId] = useState('');

  // Initialize faculty selection
  useEffect(() => {
    if (facultyData.length > 1 && !selectedFacAId) {
        setSelectedFacAId(facultyData[0].id);
        setSelectedFacBId(facultyData[1].id);
    }
  }, [facultyData]);

  // --- HELPER FUNCTIONS ---
  const handleNLQ = (e: React.FormEvent) => {
    e.preventDefault();
    if(!nlqQuery.trim()) return;
    const result = processNLQ(nlqQuery, facultyData);
    setNlqResult(result);
  };

  const toggleMic = () => {
      if (!isListening) {
          setIsListening(true);
          setTimeout(() => {
              setNlqQuery("Show departments with high burnout risk");
              setIsListening(false);
              const result = processNLQ("Show departments with high burnout risk", facultyData);
              setNlqResult(result);
          }, 2000);
      } else {
          setIsListening(false);
      }
  };

  const getMetrics = (idOrDept: string, mode: 'DEPT' | 'FACULTY') => {
      if (mode === 'DEPT') {
          const subset = facultyData.filter(f => f.dept === idOrDept);
          if(!subset.length) return null;
          const avg = (key: keyof typeof subset[0]) => Math.round(subset.reduce((a,b) => a + (b[key] as number), 0) / subset.length);
          
          return {
              name: idOrDept,
              type: 'Department',
              attendance: avg('attendanceRate'),
              workload: avg('workloadHours'),
              burnout: avg('burnoutScore'),
              leaves: avg('leavesTaken'),
              satisfaction: 100 - avg('burnoutScore') 
          };
      } else {
          const f = facultyData.find(x => x.id === idOrDept);
          if (!f) return null;
          return {
              name: f.name,
              type: f.role,
              attendance: f.attendanceRate,
              workload: f.workloadHours,
              burnout: f.burnoutScore,
              leaves: f.leavesTaken,
              satisfaction: 100 - f.burnoutScore
          };
      }
  };

  const dataA = getMetrics(compMode === 'DEPT' ? selectedDeptA : selectedFacAId, compMode);
  const dataB = getMetrics(compMode === 'DEPT' ? selectedDeptB : selectedFacBId, compMode);

  const radarData = [
      { subject: 'Attendance', A: dataA?.attendance || 0, B: dataB?.attendance || 0, fullMark: 100 },
      { subject: 'Workload', A: (dataA?.workload || 0) * 1.6, B: (dataB?.workload || 0) * 1.6, fullMark: 100 }, // Scaled to 100
      { subject: 'Wellness', A: dataA?.satisfaction || 0, B: dataB?.satisfaction || 0, fullMark: 100 },
      { subject: 'Risk Level', A: dataA?.burnout || 0, B: dataB?.burnout || 0, fullMark: 100 },
  ];

  const MetricComparisonCard = ({ label, valA, valB, unit, inverse = false }: any) => {
      const diff = valA - valB;
      const isBetter = inverse ? diff < 0 : diff > 0;
      const isEqual = diff === 0;
      
      return (
          <div className="bg-white/5 border border-white/5 rounded-xl p-4">
              <div className="text-xs text-slate-400 font-bold uppercase mb-3">{label}</div>
              <div className="flex justify-between items-end mb-2">
                  <div className="text-left">
                      <div className="text-2xl font-display font-bold text-lumina-accent">{valA}{unit}</div>
                      <div className="text-[10px] text-slate-500">Entity A</div>
                  </div>
                  <div className="mb-2">
                      {isEqual ? (
                          <span className="bg-slate-500/20 text-slate-400 px-2 py-1 rounded text-xs font-bold">= Equal</span>
                      ) : (
                          <span className={`px-2 py-1 rounded text-xs font-bold flex items-center gap-1 ${isBetter ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                              {isBetter ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                              {Math.abs(diff)}{unit}
                          </span>
                      )}
                  </div>
                  <div className="text-right">
                      <div className="text-2xl font-display font-bold text-purple-400">{valB}{unit}</div>
                      <div className="text-[10px] text-slate-500">Entity B</div>
                  </div>
              </div>
              {/* Progress Bar Visual */}
              <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden flex">
                  <div className="h-full bg-lumina-accent" style={{ width: `${(valA / (valA + valB)) * 100}%` }}></div>
                  <div className="h-full bg-purple-500" style={{ width: `${(valB / (valA + valB)) * 100}%` }}></div>
              </div>
          </div>
      );
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
            <div className="flex items-center gap-2 text-lumina-accent mb-2">
                <Sparkles size={16} />
                <span className="text-xs font-bold tracking-widest uppercase">Lumina Intelligence</span>
            </div>
            <h2 className="text-3xl font-display font-bold text-white">Analytics & Comparison</h2>
        </div>
        
        <div className="flex flex-wrap gap-2">
            <button 
                onClick={() => setPrivacyMode(!privacyMode)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold border transition-colors ${
                    privacyMode 
                    ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                    : 'bg-white/5 border-white/10 text-slate-400'
                }`}
            >
                {privacyMode ? <EyeOff size={14} /> : <Eye size={14} />}
                {privacyMode ? 'Privacy Mode On' : 'Privacy Mode Off'}
            </button>

            <div className="flex p-1 bg-white/5 rounded-xl border border-white/10">
                {['OVERVIEW', 'COMPARISON', 'SIMULATOR', 'NLQ'].map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab as any)}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                            activeTab === tab 
                            ? 'bg-lumina-accent text-lumina-base shadow-lg' 
                            : 'text-slate-400 hover:text-white'
                        }`}
                    >
                        {tab}
                    </button>
                ))}
            </div>
        </div>
      </div>

      {activeTab === 'OVERVIEW' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
            {/* Main Trend Line */}
            <div className="lg:col-span-2 glass-card p-6 rounded-2xl border border-lumina-accent/20">
                <h3 className="font-display font-bold text-lg text-white mb-2">Workforce Shortage Forecast</h3>
                <p className="text-sm text-slate-400 mb-6">AI Projection based on historical leave patterns.</p>
                <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={dailyStats}>
                            <defs>
                                <linearGradient id="colorPv" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <XAxis dataKey="date" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(str) => str.slice(5)} />
                            <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                                itemStyle={{ color: '#f8fafc' }}
                            />
                            <Area type="monotone" dataKey="totalPresent" stroke="#06b6d4" strokeWidth={3} fillOpacity={1} fill="url(#colorPv)" />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Radar Summary */}
            <div className="glass-card p-6 rounded-2xl relative overflow-hidden">
                <h3 className="font-display font-bold text-lg text-white mb-6">Department Health Radar</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                            <PolarGrid stroke="#334155" />
                            <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                            <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                            <Radar name="CS" dataKey="A" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} />
                            <Legend />
                        </RadarChart>
                    </ResponsiveContainer>
                </div>
            </div>
          </div>
      )}

      {/* --- COMPARISON DASHBOARD SYSTEM --- */}
      {activeTab === 'COMPARISON' && (
          <div className="space-y-6 animate-slide-up">
              {/* Configuration Panel */}
              <div className="glass-card p-6 rounded-2xl border border-white/10">
                  <div className="flex flex-col md:flex-row gap-6 items-center">
                      <div className="w-full md:w-auto p-1 bg-white/5 rounded-xl flex gap-1">
                           <button 
                             onClick={() => setCompMode('DEPT')}
                             className={`px-6 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${
                                 compMode === 'DEPT' ? 'bg-lumina-accent text-lumina-base shadow-lg' : 'text-slate-400 hover:text-white'
                             }`}
                           >
                               <Building2 size={16} /> Departments
                           </button>
                           <button 
                             onClick={() => setCompMode('FACULTY')}
                             className={`px-6 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${
                                 compMode === 'FACULTY' ? 'bg-lumina-accent text-lumina-base shadow-lg' : 'text-slate-400 hover:text-white'
                             }`}
                           >
                               <User size={16} /> Faculty
                           </button>
                      </div>

                      <div className="flex-1 grid grid-cols-[1fr,auto,1fr] gap-4 items-center w-full">
                          <div className="relative group">
                              <span className="absolute -top-2.5 left-3 bg-lumina-base px-2 text-[10px] font-bold text-lumina-accent uppercase">Entity A</span>
                              <select 
                                value={compMode === 'DEPT' ? selectedDeptA : selectedFacAId} 
                                onChange={e => compMode === 'DEPT' ? setSelectedDeptA(e.target.value) : setSelectedFacAId(e.target.value)} 
                                className="w-full bg-white/5 border border-lumina-accent/30 rounded-xl p-3 text-white focus:outline-none focus:border-lumina-accent"
                              >
                                  {compMode === 'DEPT' 
                                    ? DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)
                                    : facultyData.map(f => <option key={f.id} value={f.id}>{f.name}</option>)
                                  }
                              </select>
                          </div>

                          <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center font-bold text-xs text-slate-500">VS</div>

                          <div className="relative group">
                              <span className="absolute -top-2.5 left-3 bg-lumina-base px-2 text-[10px] font-bold text-purple-400 uppercase">Entity B</span>
                              <select 
                                value={compMode === 'DEPT' ? selectedDeptB : selectedFacBId} 
                                onChange={e => compMode === 'DEPT' ? setSelectedDeptB(e.target.value) : setSelectedFacBId(e.target.value)} 
                                className="w-full bg-white/5 border border-purple-500/30 rounded-xl p-3 text-white focus:outline-none focus:border-purple-500"
                              >
                                  {compMode === 'DEPT' 
                                    ? DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)
                                    : facultyData.map(f => <option key={f.id} value={f.id}>{f.name}</option>)
                                  }
                              </select>
                          </div>
                      </div>
                  </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <MetricComparisonCard 
                      label="Avg Attendance" 
                      valA={dataA?.attendance || 0} 
                      valB={dataB?.attendance || 0} 
                      unit="%" 
                  />
                  <MetricComparisonCard 
                      label="Workload / Week" 
                      valA={dataA?.workload || 0} 
                      valB={dataB?.workload || 0} 
                      unit="h" 
                      inverse={true} 
                  />
                  <MetricComparisonCard 
                      label="Burnout Risk Score" 
                      valA={dataA?.burnout || 0} 
                      valB={dataB?.burnout || 0} 
                      unit="" 
                      inverse={true} 
                  />
                  <MetricComparisonCard 
                      label="Leaves Taken" 
                      valA={dataA?.leaves || 0} 
                      valB={dataB?.leaves || 0} 
                      unit="" 
                      inverse={true} 
                  />
              </div>

              {/* Visualizations */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                   <div className="glass-card p-6 rounded-2xl lg:col-span-1">
                       <h4 className="font-bold text-white mb-4 flex items-center gap-2">
                           <Activity size={18} className="text-lumina-accent" />
                           Holistic Profile
                       </h4>
                       <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                                    <PolarGrid stroke="#334155" />
                                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                                    <Radar name={dataA?.name} dataKey="A" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} />
                                    <Radar name={dataB?.name} dataKey="B" stroke="#a855f7" fill="#a855f7" fillOpacity={0.3} />
                                    <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                                </RadarChart>
                            </ResponsiveContainer>
                       </div>
                   </div>

                   <div className="glass-card p-6 rounded-2xl lg:col-span-2">
                       <div className="flex justify-between items-center mb-6">
                           <h4 className="font-bold text-white flex items-center gap-2">
                               <Scale size={18} className="text-purple-400" />
                               Metric Breakdown
                           </h4>
                           <div className="flex gap-4 text-xs">
                               <div className="flex items-center gap-1"><div className="w-2 h-2 bg-lumina-accent rounded-full"></div> {dataA?.name}</div>
                               <div className="flex items-center gap-1"><div className="w-2 h-2 bg-purple-500 rounded-full"></div> {dataB?.name}</div>
                           </div>
                       </div>
                       <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={radarData} barCategoryGap="20%">
                                    <XAxis dataKey="subject" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                                    <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                                    <Tooltip 
                                        cursor={{fill: 'rgba(255,255,255,0.05)'}} 
                                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                                    />
                                    <Bar dataKey="A" fill="#06b6d4" radius={[4,4,0,0]} />
                                    <Bar dataKey="B" fill="#a855f7" radius={[4,4,0,0]} />
                                </BarChart>
                            </ResponsiveContainer>
                       </div>
                   </div>
              </div>
          </div>
      )}

      {activeTab === 'SIMULATOR' && (
          <div className="glass-card p-8 rounded-2xl animate-fade-in border-t-4 border-amber-500">
              <div className="flex items-center gap-3 mb-6">
                  <div className="p-3 bg-amber-500/20 text-amber-500 rounded-xl">
                      <Sliders size={24} />
                  </div>
                  <div>
                      <h3 className="text-xl font-bold text-white">"What-If" Scenario Simulator</h3>
                      <p className="text-slate-400 text-sm">Predict department collapse based on varying absenteeism.</p>
                  </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="space-y-6">
                      <div className="space-y-2">
                          <label className="font-bold text-white">Scenario: Planned Faculty Walkout / Mass Sick Leave</label>
                          <p className="text-xs text-slate-400">Target Department</p>
                          <select value={simDept} onChange={e => setSimDept(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white">
                              {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
                          </select>
                      </div>

                      <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                              <span className="text-slate-300">Absenteeism Rate</span>
                              <span className="text-amber-500 font-bold">{simLeavePercent}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="50" 
                            value={simLeavePercent} 
                            onChange={e => setSimLeavePercent(parseInt(e.target.value))}
                            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500" 
                          />
                          <div className="flex justify-between text-[10px] text-slate-500">
                              <span>0% (Normal)</span>
                              <span>25% (Critical)</span>
                              <span>50% (Collapse)</span>
                          </div>
                      </div>
                  </div>

                  <div className="bg-white/5 rounded-xl p-6 flex flex-col items-center justify-center text-center">
                      <div className="text-4xl font-display font-bold text-white mb-2">
                          {simLeavePercent > 30 ? 'CRITICAL FAILURE' : simLeavePercent > 15 ? 'HIGH STRESS' : 'OPERATIONAL'}
                      </div>
                      <div className={`text-sm font-bold px-3 py-1 rounded-full uppercase ${
                          simLeavePercent > 30 ? 'bg-rose-500/20 text-rose-500' : simLeavePercent > 15 ? 'bg-amber-500/20 text-amber-500' : 'bg-emerald-500/20 text-emerald-500'
                      }`}>
                          Predicted Impact
                      </div>
                      <p className="mt-4 text-slate-400 text-sm max-w-xs">
                          {simLeavePercent > 30 
                              ? `At ${simLeavePercent}% absence, ${simDept} will fail to cover 40% of lectures. Substitute pool exhausted.`
                              : simLeavePercent > 15 
                              ? `At ${simLeavePercent}% absence, expect 20% lecture cancellation. Substitute pool under strain.`
                              : `Department can absorb this load. Substitute pool healthy.`
                          }
                      </p>
                  </div>
              </div>
          </div>
      )}

      {activeTab === 'NLQ' && (
          <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
              <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-white mb-2">Ask AI Assistant</h3>
                  <p className="text-slate-400">Query your workforce data using natural language.</p>
              </div>

              <div className="relative">
                  <form onSubmit={handleNLQ} className="relative z-10">
                      <div className="relative group">
                          <input 
                            type="text" 
                            value={nlqQuery}
                            onChange={(e) => setNlqQuery(e.target.value)}
                            placeholder={t.nlq_placeholder}
                            className="w-full bg-lumina-surface border border-white/10 rounded-2xl pl-6 pr-32 py-5 text-lg text-white shadow-2xl focus:outline-none focus:border-lumina-accent transition-all"
                          />
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex gap-2">
                              <button 
                                type="button"
                                onClick={toggleMic}
                                className={`p-3 rounded-xl transition-colors ${isListening ? 'bg-rose-500 text-white animate-pulse' : 'bg-white/5 text-slate-400 hover:text-white'}`}
                              >
                                  <Mic size={20} />
                              </button>
                              <button 
                                type="submit"
                                className="p-3 bg-lumina-accent text-lumina-base rounded-xl hover:bg-cyan-300 transition-colors font-bold"
                              >
                                  <Send size={20} />
                              </button>
                          </div>
                      </div>
                  </form>
                  {/* Glow effect */}
                  <div className="absolute top-0 left-0 w-full h-full bg-lumina-accent/10 blur-xl -z-10 rounded-2xl"></div>
              </div>

              {nlqResult && (
                  <div className="glass-card p-6 rounded-2xl border-l-4 border-lumina-accent animate-slide-up">
                      <div className="flex items-start gap-4">
                          <div className="p-3 bg-lumina-accent/20 text-lumina-accent rounded-full">
                              <MessageSquare size={24} />
                          </div>
                          <div>
                              <div className="text-xs text-slate-500 uppercase font-bold mb-1">AI Response</div>
                              <p className="text-lg text-white leading-relaxed">{nlqResult.answer}</p>
                          </div>
                      </div>
                  </div>
              )}
          </div>
      )}
    </div>
  );
};
