import React, { useState } from 'react';
import { useApp, TRANSLATIONS } from '../services/store';
import { Calendar, Check, X, AlertOctagon, Plus, UserPlus, ShieldAlert } from 'lucide-react';
import { FacultyMetrics } from '../types';

export const Leaves = () => {
  const { leaves, isHindi, user, addLeaveRequest, updateLeaveStatus, facultyData, showToast } = useApp();
  const t = isHindi ? TRANSLATIONS.hi : TRANSLATIONS.en;
  
  const [showModal, setShowModal] = useState(false);
  const [showSubModal, setShowSubModal] = useState<string | null>(null); // Holds ID of leave being approved
  const [selectedSub, setSelectedSub] = useState<string>('');

  // FILTER
  const isAdmin = user?.role === 'ADMIN' || user?.role === 'HR';
  const displayedLeaves = isAdmin 
    ? leaves 
    : leaves.filter(l => l.facultyId === user?.id);

  // LOGIC
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    addLeaveRequest({
        id: `LR-${Date.now()}`,
        facultyId: user.id,
        facultyName: user.name,
        dept: user.dept,
        startDate: '2023-11-10',
        endDate: '2023-11-12',
        type: 'CL', // Default to CL
        status: 'Pending',
        reason: 'Generated via Demo'
    });
    setShowModal(false);
  };

  const handleApproveClick = (leaveId: string) => {
      // Open substitution modal first
      setShowSubModal(leaveId);
  };

  const confirmApproval = () => {
      if (showSubModal) {
          updateLeaveStatus(showSubModal, 'Approved');
          if (selectedSub) {
             showToast(`Substitute assigned: ${facultyData.find(f => f.id === selectedSub)?.name}`, 'info');
          }
          setShowSubModal(null);
          setSelectedSub('');
      }
  };

  const handleReject = (id: string) => {
      if (window.confirm("Deny this request?")) {
          updateLeaveStatus(id, 'Rejected');
      }
  };

  // Helper to find potential substitutes
  const getSubstitutes = (dept: string): FacultyMetrics[] => {
      // Simple logic: Same dept, not on leave (mocked), low workload
      return facultyData
        .filter(f => f.dept === dept && f.workloadHours < 40)
        .sort((a, b) => a.workloadHours - b.workloadHours) // Suggest least loaded first
        .slice(0, 3);
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="flex justify-between items-center">
        <div>
            <h2 className="text-3xl font-display font-bold text-white">Leave Intelligence</h2>
            <p className="text-xs text-slate-400 mt-1">Indian Policy Engine Active (AICTE Norms)</p>
        </div>
        
        <button 
            onClick={() => setShowModal(true)}
            className="px-5 py-2.5 bg-lumina-accent text-lumina-base hover:bg-cyan-300 rounded-xl transition-colors font-bold flex items-center gap-2"
        >
            <Plus size={18} />
            Request Leave
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayedLeaves.map((leave, idx) => (
            <div 
                key={leave.id} 
                className={`glass-card p-6 rounded-2xl border-l-4 ${leave.riskFlag ? 'border-lumina-danger' : 'border-slate-600'} animate-slide-up`}
                style={{ animationDelay: `${idx * 100}ms` }}
            >
                <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
                            <Calendar size={18} />
                        </div>
                        <div>
                            <h4 className="font-bold text-white">{leave.facultyName}</h4>
                            <div className="text-xs text-slate-400">{leave.dept}</div>
                        </div>
                    </div>
                    {leave.riskFlag && isAdmin && (
                        <div className="flex items-center gap-1 px-2 py-1 rounded bg-lumina-danger/10 border border-lumina-danger/20 text-lumina-danger text-[10px] font-bold uppercase tracking-wide">
                            <AlertOctagon size={10} /> Cluster Risk
                        </div>
                    )}
                </div>
                
                <div className="space-y-2 mb-6">
                    <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Duration</span>
                        <span className="text-white font-mono">{leave.startDate} to {leave.endDate}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Type</span>
                        <span className="text-slate-200 font-medium px-2 py-0.5 bg-white/5 rounded">{leave.type}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Status</span>
                        <span className={`font-bold ${
                            leave.status === 'Approved' ? 'text-emerald-400' :
                            leave.status === 'Rejected' ? 'text-rose-400' : 'text-amber-400'
                        }`}>{leave.status}</span>
                    </div>
                    {/* Policy Check */}
                    {leave.type === 'CL' && (
                        <div className="flex items-center gap-2 mt-2 pt-2 border-t border-white/5">
                            <ShieldAlert size={12} className="text-emerald-500" />
                            <span className="text-[10px] text-slate-400">Within CL Limit (8 Remaining)</span>
                        </div>
                    )}
                </div>

                {leave.status === 'Pending' && isAdmin && (
                    <div className="flex gap-2">
                        <button 
                            onClick={() => handleApproveClick(leave.id)}
                            className="flex-1 py-2 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20 flex items-center justify-center gap-2 text-sm font-bold transition-colors"
                        >
                            <Check size={16} /> Approve
                        </button>
                        <button 
                            onClick={() => handleReject(leave.id)}
                            className="flex-1 py-2 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border border-rose-500/20 flex items-center justify-center gap-2 text-sm font-bold transition-colors"
                        >
                            <X size={16} /> Deny
                        </button>
                    </div>
                )}
            </div>
        ))}
      </div>

      {/* Request Modal */}
      {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
              <div className="glass-card w-full max-w-lg p-8 rounded-3xl border border-white/20">
                  <h3 className="text-xl font-bold text-white mb-6">New Leave Request</h3>
                  <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                          <label className="block text-xs text-slate-400 mb-1">Dates</label>
                          <div className="flex gap-4">
                            <input type="date" className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-white" required />
                            <input type="date" className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-white" required />
                          </div>
                      </div>
                      <div>
                          <label className="block text-xs text-slate-400 mb-1">Type (Indian Policy)</label>
                          <select className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white">
                              <option value="CL">Casual Leave (CL)</option>
                              <option value="SL">Sick Leave (SL)</option>
                              <option value="EL">Earned Leave (EL/PL)</option>
                              <option value="OD">On Duty (OD)</option>
                          </select>
                      </div>
                      <div>
                          <label className="block text-xs text-slate-400 mb-1">Reason</label>
                          <textarea className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white h-24" placeholder="Reason..."></textarea>
                      </div>
                      <div className="flex gap-3 pt-4">
                          <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-3 text-slate-400 hover:text-white">Cancel</button>
                          <button type="submit" className="flex-1 py-3 bg-lumina-accent text-lumina-base font-bold rounded-xl hover:bg-cyan-300">Submit</button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      {/* Substitution Modal */}
      {showSubModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
              <div className="glass-card w-full max-w-md p-6 rounded-3xl border border-white/20">
                  <div className="text-center mb-6">
                      <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-3">
                          <UserPlus size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-white">Assign Substitute</h3>
                      <p className="text-sm text-slate-400">Select a faculty member to cover classes.</p>
                  </div>
                  
                  <div className="space-y-2 mb-6">
                      <p className="text-xs font-bold text-slate-500 uppercase">AI Suggested Substitutes</p>
                      {getSubstitutes(leaves.find(l => l.id === showSubModal)?.dept || '').map(sub => (
                          <div 
                            key={sub.id}
                            onClick={() => setSelectedSub(sub.id)}
                            className={`p-3 rounded-xl border cursor-pointer flex justify-between items-center transition-all ${
                                selectedSub === sub.id 
                                ? 'bg-lumina-accent/20 border-lumina-accent text-white' 
                                : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10'
                            }`}
                          >
                              <div>
                                  <div className="font-bold text-sm">{sub.name}</div>
                                  <div className="text-[10px] opacity-70">Skills Match: {sub.skills[0]}</div>
                              </div>
                              <div className="text-right">
                                  <div className="text-xs font-mono">{sub.workloadHours}h Load</div>
                              </div>
                          </div>
                      ))}
                      
                      <div className="mt-4 pt-4 border-t border-white/10">
                           <label className="flex items-center gap-2 text-sm text-slate-400">
                               <input 
                                    type="checkbox" 
                                    checked={!selectedSub} 
                                    onChange={() => setSelectedSub('')}
                                    className="rounded bg-white/10 border-white/20"
                                />
                               No substitute required
                           </label>
                      </div>
                  </div>

                  <div className="flex gap-3">
                      <button onClick={() => setShowSubModal(null)} className="flex-1 py-3 text-slate-400 hover:text-white">Cancel</button>
                      <button onClick={confirmApproval} className="flex-1 py-3 bg-emerald-500 text-white font-bold rounded-xl hover:bg-emerald-400">Confirm & Approve</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
