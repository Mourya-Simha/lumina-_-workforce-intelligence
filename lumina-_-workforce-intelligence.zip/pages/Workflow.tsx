import React, { useState, useEffect, useMemo } from 'react';
import { useApp, TRANSLATIONS } from '../services/store';
import { generateSchedule } from '../services/dataService';
import { Calendar, Clock, MapPin, Search, ArrowRightLeft, User, Briefcase, XCircle, Edit2, Save, Plus } from 'lucide-react';
import { ScheduleEvent, FacultyMetrics, DEPARTMENTS } from '../types';

export const Workflow = () => {
  const { user, facultyData, showToast, isHindi } = useApp();
  const isAdmin = user?.role === 'ADMIN' || user?.role === 'HR';
  const t = isHindi ? TRANSLATIONS.hi : TRANSLATIONS.en;

  // --- ADMIN STATE ---
  const [selectedFacId, setSelectedFacId] = useState<string | null>(null); // For detailed single view
  const [comparisonMode, setComparisonMode] = useState(false);
  const [compareA, setCompareA] = useState<string>('');
  const [compareB, setCompareB] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [deptFilter, setDeptFilter] = useState('ALL');

  // --- EDITING STATE ---
  const [schedule, setSchedule] = useState<ScheduleEvent[]>([]);
  const [editingEvent, setEditingEvent] = useState<ScheduleEvent | null>(null);

  // --- VIEW LOGIC ---
  const activeFacultyId = isAdmin ? (selectedFacId || facultyData[0]?.id) : (user?.id || '');
  
  // Load Schedule Effect
  useEffect(() => {
    if (activeFacultyId) {
        setSchedule(generateSchedule(activeFacultyId));
    }
  }, [activeFacultyId]);

  const handleSaveEvent = () => {
    if (!editingEvent) return;
    
    // Sort events after update to keep timeline chronological
    setSchedule(prev => {
        const updated = prev.map(ev => ev.id === editingEvent.id ? editingEvent : ev);
        return updated.sort((a, b) => a.startTime.localeCompare(b.startTime));
    });
    
    setEditingEvent(null);
    showToast("Schedule updated successfully", "success");
  };
  
  const getEventTypeLabel = (type: string) => {
    switch(type) {
        case 'LECTURE': return t.lecture;
        case 'LAB': return t.lab;
        case 'RESEARCH': return t.research;
        case 'ADMIN': return t.admin;
        default: return type;
    }
  };

  // Data for Comparison (Read Only for now)
  const scheduleA = useMemo(() => compareA ? generateSchedule(compareA) : [], [compareA]);
  const scheduleB = useMemo(() => compareB ? generateSchedule(compareB) : [], [compareB]);

  const filteredFaculty = facultyData.filter(f => {
      const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) || f.dept.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDept = deptFilter === 'ALL' || f.dept === deptFilter;
      return matchesSearch && matchesDept;
  });

  // Group faculty for dropdowns
  const facultyByDept = useMemo(() => {
    const groups: Record<string, FacultyMetrics[]> = {};
    DEPARTMENTS.forEach(d => groups[d] = []);
    facultyData.forEach(f => {
       if (groups[f.dept]) groups[f.dept].push(f);
       else groups[f.dept] = [f];
    });
    return groups;
  }, [facultyData]);

  // --- SUB-COMPONENTS ---
  const TimelineEvent: React.FC<{ event: ScheduleEvent, isEditable?: boolean }> = ({ event, isEditable = false }) => (
      <div className="relative pl-8 pb-8 border-l border-white/10 last:pb-0 group">
          <div className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full border-2 border-lumina-base transition-colors ${
              event.type === 'LECTURE' ? 'bg-lumina-accent' :
              event.type === 'LAB' ? 'bg-purple-500' :
              event.type === 'RESEARCH' ? 'bg-emerald-500' : 'bg-slate-500'
          }`}></div>
          
          <div className="bg-white/5 border border-white/5 rounded-xl p-4 hover:bg-white/10 transition-colors group/card relative">
              {isEditable && (
                  <button 
                    onClick={() => setEditingEvent(event)}
                    className="absolute top-3 right-3 p-2 rounded-lg bg-black/20 hover:bg-black/40 text-slate-400 hover:text-white opacity-0 group-hover/card:opacity-100 transition-all z-10"
                    title="Edit Event"
                  >
                      <Edit2 size={14} />
                  </button>
              )}

              <div className="flex justify-between items-start mb-2 pr-8">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                      event.type === 'LECTURE' ? 'bg-lumina-accent/10 text-lumina-accent' :
                      event.type === 'LAB' ? 'bg-purple-500/10 text-purple-400' :
                      event.type === 'RESEARCH' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-500/10 text-slate-400'
                  }`}>{getEventTypeLabel(event.type)}</span>
                  <div className="flex items-center gap-1 text-xs text-slate-400">
                      <Clock size={12} />
                      {event.startTime} - {event.endTime}
                  </div>
              </div>
              <h4 className="text-white font-bold mb-1">{event.title}</h4>
              {event.location && (
                  <div className="flex items-center gap-1 text-xs text-slate-500">
                      <MapPin size={12} /> {event.location}
                  </div>
              )}
          </div>
      </div>
  );

  const FacultySelector: React.FC<{ value: string, onChange: (val: string) => void, label: string }> = ({ value, onChange, label }) => (
      <div>
        <label className="text-xs font-bold text-slate-500 uppercase mb-2 block">{label}</label>
        <div className="relative">
            <select 
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white appearance-none focus:border-lumina-accent focus:outline-none transition-colors"
                value={value}
                onChange={(e) => onChange(e.target.value)}
            >
                <option value="">{t.selectFaculty}</option>
                {Object.entries(facultyByDept).map(([dept, faculty]) => (
                    <optgroup key={dept} label={dept} className="bg-slate-900 text-slate-300">
                        {(faculty as FacultyMetrics[]).map(f => (
                            <option key={f.id} value={f.id} className="text-white">
                                {f.name}
                            </option>
                        ))}
                    </optgroup>
                ))}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                <User size={16} />
            </div>
        </div>
      </div>
  );

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
          <div>
              <h2 className="text-3xl font-display font-bold text-white">{t.workflowTitle}</h2>
              <p className="text-slate-400 text-sm mt-1">
                  {isAdmin ? t.workflowDescAdmin : t.workflowDesc}
              </p>
          </div>
          {isAdmin && (
              <button 
                onClick={() => setComparisonMode(!comparisonMode)}
                className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 border transition-colors ${
                    comparisonMode 
                    ? 'bg-lumina-accent text-lumina-base border-lumina-accent shadow-lg shadow-lumina-accent/20' 
                    : 'bg-white/5 text-white border-white/10 hover:bg-white/10'
                }`}
              >
                  <ArrowRightLeft size={16} />
                  {comparisonMode ? t.exitCompare : t.compare}
              </button>
          )}
      </div>

      {/* --- ADMIN: COMPARISON MODE --- */}
      {isAdmin && comparisonMode ? (
          <div className="space-y-6 animate-slide-up">
              <div className="glass-card p-6 rounded-2xl border border-white/10">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center relative">
                      <FacultySelector value={compareA} onChange={setCompareA} label={t.facultyA} />
                      
                      <div className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/5 items-center justify-center text-slate-500 border border-white/5 z-10">
                          <span className="font-bold text-xs">{t.vs}</span>
                      </div>
                      
                      <FacultySelector value={compareB} onChange={setCompareB} label={t.facultyB} />
                  </div>
                  <p className="text-xs text-slate-500 mt-4 text-center border-t border-white/5 pt-4">
                      * Comparing individual workflows across any department is permitted. Department-level aggregate comparison is disabled.
                  </p>
              </div>

              {compareA && compareB ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Timeline A */}
                      <div className="glass-card p-6 rounded-2xl border-t-4 border-indigo-500">
                           <div className="flex items-center gap-3 mb-6 border-b border-white/5 pb-4">
                                <div className="w-10 h-10 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                                    <User size={20} />
                                </div>
                                <div>
                                    <h3 className="font-bold text-white text-lg">{facultyData.find(f => f.id === compareA)?.name}</h3>
                                    <p className="text-xs text-slate-400">{facultyData.find(f => f.id === compareA)?.dept}</p>
                                </div>
                           </div>
                           <div className="space-y-2">
                               {scheduleA.length > 0 ? (
                                   scheduleA.map(ev => <TimelineEvent key={ev.id} event={ev} />)
                               ) : (
                                   <div className="text-center py-8 text-slate-500 bg-white/5 rounded-xl border border-dashed border-white/10">
                                       <Briefcase size={24} className="mx-auto mb-2 opacity-50" />
                                       <p className="text-sm">{t.noEvents}</p>
                                   </div>
                               )}
                           </div>
                      </div>

                      {/* Timeline B */}
                      <div className="glass-card p-6 rounded-2xl border-t-4 border-cyan-500">
                           <div className="flex items-center gap-3 mb-6 border-b border-white/5 pb-4">
                                <div className="w-10 h-10 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                                    <User size={20} />
                                </div>
                                <div>
                                    <h3 className="font-bold text-white text-lg">{facultyData.find(f => f.id === compareB)?.name}</h3>
                                    <p className="text-xs text-slate-400">{facultyData.find(f => f.id === compareB)?.dept}</p>
                                </div>
                           </div>
                           <div className="space-y-2">
                               {scheduleB.length > 0 ? (
                                   scheduleB.map(ev => <TimelineEvent key={ev.id} event={ev} />)
                               ) : (
                                   <div className="text-center py-8 text-slate-500 bg-white/5 rounded-xl border border-dashed border-white/10">
                                       <Briefcase size={24} className="mx-auto mb-2 opacity-50" />
                                       <p className="text-sm">{t.noEvents}</p>
                                   </div>
                               )}
                           </div>
                      </div>
                  </div>
              ) : (
                  <div className="text-center py-12 border border-dashed border-white/10 rounded-2xl bg-white/5">
                      <ArrowRightLeft size={32} className="mx-auto mb-3 text-slate-600" />
                      <p className="text-slate-400 font-medium">Select two faculty members to compare schedules</p>
                  </div>
              )}
          </div>
      ) : (
          /* --- STANDARD VIEW (Faculty or Admin Selection) --- */
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column: Faculty List (Admin Only) or Context Info */}
              {isAdmin && (
                  <div className="space-y-6">
                      <div className="glass-card p-4 rounded-2xl space-y-4">
                          <div className="relative">
                              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
                              <input 
                                type="text" 
                                placeholder={t.searchFaculty}
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                                className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-lumina-accent/50"
                              />
                          </div>
                          <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
                              <button 
                                onClick={() => setDeptFilter('ALL')}
                                className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${deptFilter === 'ALL' ? 'bg-white/10 text-white border-white/20' : 'text-slate-500 border-transparent hover:text-white'}`}
                              >
                                  {t.all}
                              </button>
                              {DEPARTMENTS.map(d => (
                                  <button 
                                    key={d}
                                    onClick={() => setDeptFilter(d)}
                                    className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${deptFilter === d ? 'bg-white/10 text-white border-white/20' : 'text-slate-500 border-transparent hover:text-white'}`}
                                  >
                                      {d}
                                  </button>
                              ))}
                          </div>
                      </div>

                      <div className="glass-card rounded-2xl overflow-hidden max-h-[600px] overflow-y-auto custom-scrollbar">
                          {filteredFaculty.map(f => (
                              <button 
                                key={f.id}
                                onClick={() => setSelectedFacId(f.id)}
                                className={`w-full text-left p-4 border-b border-white/5 hover:bg-white/5 transition-colors flex items-center gap-3 ${selectedFacId === f.id ? 'bg-white/10 border-l-4 border-l-lumina-accent' : ''}`}
                              >
                                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                                      {f.name.charAt(0)}
                                  </div>
                                  <div className="min-w-0">
                                      <div className="text-sm font-bold text-white truncate">{f.name}</div>
                                      <div className="text-[10px] text-slate-400 truncate">{f.dept}</div>
                                  </div>
                              </button>
                          ))}
                          {filteredFaculty.length === 0 && (
                              <div className="p-8 text-center text-slate-500 text-sm">No faculty found.</div>
                          )}
                      </div>
                  </div>
              )}

              {/* Right Column: The Schedule Timeline */}
              <div className={`glass-card p-8 rounded-3xl ${isAdmin ? 'lg:col-span-2' : 'lg:col-span-3'}`}>
                  <div className="flex justify-between items-start mb-8">
                       <div className="flex items-center gap-4">
                           <div className="p-3 bg-lumina-accent/10 rounded-xl text-lumina-accent">
                               <Calendar size={24} />
                           </div>
                           <div>
                               <h3 className="text-xl font-bold text-white">
                                   {isAdmin && selectedFacId 
                                      ? facultyData.find(f => f.id === selectedFacId)?.name 
                                      : user?.name}
                               </h3>
                               <p className="text-sm text-slate-400">
                                   {new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                               </p>
                           </div>
                       </div>
                       <div className="text-right hidden sm:block">
                           <div className="text-2xl font-display font-bold text-white">
                               {schedule.length}
                           </div>
                           <div className="text-xs text-slate-400 uppercase tracking-wider">{t.eventsToday}</div>
                       </div>
                  </div>

                  <div className="space-y-2">
                      {schedule.map(event => (
                          <TimelineEvent key={event.id} event={event} isEditable={true} />
                      ))}
                      {schedule.length === 0 && (
                          <div className="text-center py-12 text-slate-500 bg-white/5 rounded-2xl border border-dashed border-white/10">
                              <Briefcase size={32} className="mx-auto mb-3 opacity-50" />
                              <p>{t.noWorkflow}</p>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {/* --- EDIT MODAL --- */}
      {editingEvent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
              <div className="glass-card w-full max-w-md p-6 rounded-3xl border border-white/20">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-white">{t.editSchedule}</h3>
                      <button onClick={() => setEditingEvent(null)} className="text-slate-400 hover:text-white"><XCircle size={24} /></button>
                  </div>
                  
                  <div className="space-y-4">
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.eventTitle}</label>
                          <input 
                              type="text" 
                              value={editingEvent.title} 
                              onChange={e => setEditingEvent({...editingEvent, title: e.target.value})}
                              className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none focus:bg-white/10 transition-colors"
                          />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.startTime}</label>
                              <input 
                                  type="time" 
                                  value={editingEvent.startTime} 
                                  onChange={e => setEditingEvent({...editingEvent, startTime: e.target.value})}
                                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none focus:bg-white/10 transition-colors"
                              />
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.endTime}</label>
                              <input 
                                  type="time" 
                                  value={editingEvent.endTime} 
                                  onChange={e => setEditingEvent({...editingEvent, endTime: e.target.value})}
                                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none focus:bg-white/10 transition-colors"
                              />
                          </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.eventType}</label>
                              <select 
                                  value={editingEvent.type}
                                  onChange={e => setEditingEvent({...editingEvent, type: e.target.value as any})}
                                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none focus:bg-white/10 transition-colors"
                              >
                                  <option value="LECTURE" className="bg-slate-900">{t.lecture}</option>
                                  <option value="LAB" className="bg-slate-900">{t.lab}</option>
                                  <option value="RESEARCH" className="bg-slate-900">{t.research}</option>
                                  <option value="ADMIN" className="bg-slate-900">{t.admin}</option>
                              </select>
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">{t.location}</label>
                              <input 
                                  type="text" 
                                  value={editingEvent.location} 
                                  onChange={e => setEditingEvent({...editingEvent, location: e.target.value})}
                                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none focus:bg-white/10 transition-colors"
                              />
                          </div>
                      </div>

                      <div className="pt-4 flex gap-3">
                          <button 
                              onClick={() => setEditingEvent(null)}
                              className="flex-1 py-3 text-slate-400 hover:text-white font-bold transition-colors"
                          >
                              {t.cancel}
                          </button>
                          <button 
                              onClick={handleSaveEvent}
                              className="flex-1 py-3 bg-lumina-accent text-lumina-base rounded-xl font-bold hover:bg-cyan-300 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-cyan-900/50"
                          >
                              <Save size={18} /> {t.saveChanges}
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};