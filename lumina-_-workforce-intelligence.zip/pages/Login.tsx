import React, { useState } from 'react';
import { useApp } from '../services/store';
import { BrainCircuit, Play, ShieldCheck, ChevronRight } from 'lucide-react';

export const Login = () => {
  const { login, isLoading } = useApp();
  const [showPitch, setShowPitch] = useState(false);

  return (
    <div className="min-h-screen bg-lumina-base text-white relative overflow-hidden flex flex-col justify-center items-center p-6">
      {/* Dynamic Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-indigo-900/20 rounded-full blur-[120px] animate-pulse-slow"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-cyan-900/20 rounded-full blur-[120px] animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="relative z-10 max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Left: Hero */}
        <div className="space-y-8 animate-slide-up">
            <div className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 rounded-xl bg-lumina-accent flex items-center justify-center">
                    <BrainCircuit className="text-lumina-base w-6 h-6" />
                </div>
                <h1 className="font-display font-bold text-3xl tracking-tighter">LUMINA</h1>
            </div>

            <h2 className="text-5xl md:text-6xl font-display font-bold leading-[1.1]">
                Workforce Intelligence <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-lumina-accent to-purple-400">Reimagined.</span>
            </h2>
            
            <p className="text-lg text-slate-400 max-w-md leading-relaxed">
                The first AI-driven platform for university faculty management. Predict burnout, optimize substitutes, and track attendance with precision.
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
                <button 
                    onClick={() => setShowPitch(true)}
                    className="group px-6 py-3 rounded-full border border-white/20 hover:bg-white/5 transition-all flex items-center gap-2 text-sm font-bold"
                >
                    <Play size={16} className="text-lumina-accent group-hover:scale-110 transition-transform" />
                    Hackathon Pitch
                </button>
                <div className="px-6 py-3 rounded-full bg-white/5 border border-white/10 text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <ShieldCheck size={16} /> Enterprise Secure
                </div>
            </div>
        </div>

        {/* Right: Auth Card */}
        <div className="glass-card p-8 md:p-12 rounded-3xl border border-white/10 shadow-2xl shadow-indigo-500/10 animate-slide-up" style={{ animationDelay: '200ms' }}>
            <h3 className="text-2xl font-display font-bold mb-2">Access Portal</h3>
            <p className="text-slate-400 mb-8 text-sm">Select your role to view the demo environment.</p>

            <div className="space-y-4">
                <button 
                    onClick={() => login('ADMIN')}
                    disabled={isLoading}
                    className="w-full p-4 rounded-xl bg-gradient-to-r from-lumina-accent to-cyan-600 hover:from-cyan-400 hover:to-cyan-500 transition-all text-white font-bold flex justify-between items-center group shadow-lg shadow-cyan-900/50"
                >
                    <span className="flex items-center gap-3">
                        <span className="bg-white/20 p-1.5 rounded-lg"><BrainCircuit size={18} /></span>
                        Admin Dashboard
                    </span>
                    {isLoading ? <span className="animate-spin">...</span> : <ChevronRight className="group-hover:translate-x-1 transition-transform" />}
                </button>

                <button 
                    onClick={() => login('FACULTY')}
                    disabled={isLoading}
                    className="w-full p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-white font-bold flex justify-between items-center group"
                >
                    <span className="flex items-center gap-3">
                         <span className="bg-white/10 p-1.5 rounded-lg"><ShieldCheck size={18} /></span>
                         Faculty Portal
                    </span>
                    <ChevronRight className="group-hover:translate-x-1 transition-transform opacity-50" />
                </button>
            </div>

            <div className="mt-8 pt-8 border-t border-white/5 text-center">
                <p className="text-xs text-slate-500 uppercase tracking-widest font-bold">Powered by Google Gemini & Python Flask</p>
            </div>
        </div>
      </div>

      {/* Pitch Deck Modal */}
      {showPitch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
            <div className="glass-card max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-3xl p-8 border border-white/20 relative">
                <button onClick={() => setShowPitch(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">✕</button>
                <h2 className="text-2xl font-display font-bold mb-6 text-lumina-accent">Hackathon Pitch: Lumina</h2>
                
                <div className="space-y-6 text-slate-300">
                    <div>
                        <h3 className="text-white font-bold mb-1">The Problem</h3>
                        <p>Universities face a "Silent Crisis": Faculty burnout (42% attrition) and inefficient manual leave management lead to last-minute class cancellations and poor student outcomes.</p>
                    </div>
                    <div>
                        <h3 className="text-white font-bold mb-1">The Solution</h3>
                        <p>Lumina is a data-first platform that uses predictive analytics to flag burnout risks before they happen, automates leave clustering detection, and provides smart substitute suggestions.</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                            <h4 className="text-white font-bold text-sm">Tech Stack</h4>
                            <ul className="text-xs list-disc list-inside mt-2 space-y-1">
                                <li>React + Tailwind (Shadcn/UI style)</li>
                                <li>Python Flask Backend</li>
                                <li>Scikit-Learn (Anomaly Detection)</li>
                                <li>Firebase Auth & Database</li>
                            </ul>
                        </div>
                        <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                            <h4 className="text-white font-bold text-sm">Impact</h4>
                            <ul className="text-xs list-disc list-inside mt-2 space-y-1">
                                <li>95% reduction in scheduling conflicts</li>
                                <li>Early warning for faculty burnout</li>
                                <li>Automated substitute matching</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
