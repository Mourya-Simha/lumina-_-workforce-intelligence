import React, { useState } from 'react';
import { useApp } from '../services/store';
import { QrCode, Search, Filter, Clock, MapPin, CheckCircle, Download, FileSpreadsheet, Calendar, ChevronDown, ChevronUp, RefreshCw, X } from 'lucide-react';

export const Attendance = () => {
  const { facultyData, user } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [clockedIn, setClockedIn] = useState(false);
  const [showQr, setShowQr] = useState(false);
  
  // Advanced Filters State
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PRESENT' | 'ABSENT' | 'LATE'>('ALL');
  const [sourceFilter, setSourceFilter] = useState<'ALL' | 'QR' | 'MANUAL'>('ALL');
  const [dateRange, setDateRange] = useState({
      start: new Date().toISOString().split('T')[0],
      end: new Date().toISOString().split('T')[0]
  });

  const isAdmin = user?.role === 'ADMIN' || user?.role === 'HR';

  // Process data with simulated fields for filtering
  const processedData = facultyData.map(f => {
      // Simulation logic for demo purposes
      // In a real app, this would come from the daily attendance record fetch
      const isPresent = f.attendanceRate > 85;
      const isLate = isPresent && f.attendanceRate < 92; // Simulate Late if barely passing
      
      let status: 'PRESENT' | 'ABSENT' | 'LATE' = 'ABSENT';
      if (isPresent) status = isLate ? 'LATE' : 'PRESENT';
      
      // Simulate source based on ID parity
      const source: 'QR' | 'MANUAL' = parseInt(f.id.replace('FAC-', '')) % 2 === 0 ? 'QR' : 'MANUAL';
      
      return { ...f, derivedStatus: status, derivedSource: source };
  });

  const filteredFaculty = processedData.filter(f => {
    if (!isAdmin && f.id !== user?.id) {
        return false;
    }

    const matchesSearch = f.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
           f.dept.toLowerCase().includes(searchTerm.toLowerCase());
           
    const matchesStatus = statusFilter === 'ALL' || f.derivedStatus === statusFilter;
    const matchesSource = sourceFilter === 'ALL' || f.derivedSource === sourceFilter;
    
    // Date filtering is visual-only in this mock since we don't have historical records loaded
    // but we simulate the UI interaction
    
    return matchesSearch && matchesStatus && matchesSource;
  });

  const handleExport = () => {
    alert(`Downloading CSV report for ${dateRange.start} to ${dateRange.end}...`);
  };

  const clearFilters = () => {
      setStatusFilter('ALL');
      setSourceFilter('ALL');
      setSearchTerm('');
      setDateRange({
          start: new Date().toISOString().split('T')[0],
          end: new Date().toISOString().split('T')[0]
      });
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in relative">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-3xl font-display font-bold text-white">Attendance Tracking</h2>
        
        <div className="flex gap-3 w-full md:w-auto">
            {/* Clock In is relevant for Faculty mostly, or testing */}
            <button 
                onClick={() => setShowQr(true)}
                className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
                    clockedIn 
                    ? 'bg-lumina-success/20 text-lumina-success border border-lumina-success/50' 
                    : 'bg-lumina-accent text-lumina-base hover:bg-cyan-300'
                }`}
            >
                {clockedIn ? <CheckCircle size={18} /> : <QrCode size={18} />}
                {clockedIn ? 'Clocked In' : 'QR Clock In'}
            </button>
        </div>
      </div>

      {/* Clock In Widget */}
      <div className="glass-card p-6 rounded-2xl flex items-center justify-between border-l-4 border-lumina-accent">
        <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-slate-400">
                <Clock size={24} />
            </div>
            <div>
                <div className="text-sm text-lumina-muted">Current Session</div>
                <div className="text-xl font-display font-bold text-white">
                    {new Date().toLocaleTimeString()}
                </div>
            </div>
        </div>
        <div className="text-right hidden sm:block">
            <div className="flex items-center gap-1 text-xs text-lumina-muted justify-end">
                <MapPin size={12} /> Campus Main Gate
            </div>
            <div className="text-emerald-400 text-sm font-bold">Geofence Active</div>
        </div>
      </div>

      {/* Admin Controls */}
      {isAdmin && (
          <div className="space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-lumina-muted w-4 h-4" />
                    <input 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        type="text" 
                        placeholder="Search faculty name or ID..." 
                        className="w-full bg-lumina-surface border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-white focus:outline-none focus:border-lumina-accent/50"
                    />
                </div>
                <button 
                    onClick={() => setShowFilters(!showFilters)}
                    className={`px-4 py-3 border rounded-xl flex items-center gap-2 transition-colors ${
                        showFilters 
                        ? 'bg-lumina-accent text-lumina-base border-lumina-accent font-bold' 
                        : 'bg-lumina-surface border-white/10 text-slate-300 hover:text-white'
                    }`}
                >
                    <Filter size={18} />
                    <span className="hidden md:inline text-xs font-bold">Filters</span>
                    {showFilters ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                </button>
                <button 
                    onClick={handleExport}
                    className="px-4 py-3 bg-lumina-surface border border-white/10 rounded-xl text-slate-300 hover:text-white flex items-center gap-2"
                >
                    <Download size={18} />
                    <span className="hidden md:inline text-xs font-bold">Export CSV</span>
                </button>
              </div>

              {/* Advanced Filter Panel */}
              {showFilters && (
                  <div className="glass-card p-6 rounded-2xl animate-slide-up border border-white/10 grid grid-cols-1 md:grid-cols-4 gap-6">
                      <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase">Date Range</label>
                          <div className="flex items-center gap-2">
                              <input 
                                type="date" 
                                value={dateRange.start}
                                onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
                                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-xs"
                              />
                              <span className="text-slate-500">-</span>
                              <input 
                                type="date" 
                                value={dateRange.end}
                                onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
                                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-xs"
                              />
                          </div>
                      </div>

                      <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase">Status</label>
                          <select 
                            value={statusFilter}
                            onChange={(e) => setStatusFilter(e.target.value as any)}
                            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                          >
                              <option value="ALL">All Statuses</option>
                              <option value="PRESENT">Present</option>
                              <option value="LATE">Late</option>
                              <option value="ABSENT">Absent</option>
                          </select>
                      </div>

                      <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase">Source</label>
                          <select 
                            value={sourceFilter}
                            onChange={(e) => setSourceFilter(e.target.value as any)}
                            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                          >
                              <option value="ALL">All Sources</option>
                              <option value="QR">QR Scan</option>
                              <option value="MANUAL">Manual Entry</option>
                          </select>
                      </div>

                      <div className="flex items-end">
                          <button 
                            onClick={clearFilters}
                            className="w-full py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-slate-300 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                          >
                              <RefreshCw size={14} /> Reset Filters
                          </button>
                      </div>
                  </div>
              )}
          </div>
      )}

      {/* List */}
      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="border-b border-white/5 bg-white/5">
                        <th className="p-4 text-xs font-bold text-lumina-muted uppercase tracking-wider">Faculty Member</th>
                        <th className="p-4 text-xs font-bold text-lumina-muted uppercase tracking-wider">Dept</th>
                        <th className="p-4 text-xs font-bold text-lumina-muted uppercase tracking-wider">Status</th>
                        <th className="p-4 text-xs font-bold text-lumina-muted uppercase tracking-wider">Source</th>
                        <th className="p-4 text-xs font-bold text-lumina-muted uppercase tracking-wider text-right">Check In</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredFaculty.slice(0, 15).map((f) => (
                        <tr key={f.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                            <td className="p-4">
                                <div className="font-medium text-white">{f.name}</div>
                                <div className="text-xs text-slate-500">{f.id}</div>
                            </td>
                            <td className="p-4 text-sm text-slate-300">{f.dept}</td>
                            <td className="p-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-bold border ${
                                    f.derivedStatus === 'PRESENT' 
                                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                                    : f.derivedStatus === 'LATE'
                                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                                    : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                                }`}>
                                    {f.derivedStatus}
                                </span>
                            </td>
                            <td className="p-4">
                                <div className="flex items-center gap-2 text-sm text-slate-400">
                                    {f.derivedSource === 'QR' ? <QrCode size={14} /> : <FileSpreadsheet size={14} />}
                                    {f.derivedSource}
                                </div>
                            </td>
                            <td className="p-4 text-right text-sm text-slate-400 font-mono">
                                {f.derivedStatus === 'ABSENT' ? '--:--' : 
                                 f.derivedStatus === 'LATE' ? '09:42 AM' : '08:55 AM'}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        {filteredFaculty.length === 0 && (
            <div className="p-12 text-center text-slate-500 flex flex-col items-center">
                <Search size={32} className="mb-3 opacity-50" />
                <p>No attendance records match your filters.</p>
                <button onClick={clearFilters} className="mt-4 text-lumina-accent text-sm hover:underline">Clear all filters</button>
            </div>
        )}
      </div>

      {/* QR Modal Simulation */}
      {showQr && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-fade-in">
              <div className="bg-white p-8 rounded-3xl max-w-sm w-full text-center relative">
                  <button onClick={() => setShowQr(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600">✕</button>
                  <h3 className="text-slate-900 font-bold text-xl mb-2">Scan to Clock In</h3>
                  <p className="text-slate-500 text-sm mb-6">Use your faculty mobile app</p>
                  <div className="bg-slate-900 p-4 rounded-xl inline-block mb-6">
                      {/* Fake QR */}
                      <div className="w-48 h-48 bg-white flex items-center justify-center">
                          <div className="grid grid-cols-5 gap-1">
                              {[...Array(25)].map((_, i) => (
                                  <div key={i} className={`w-8 h-8 ${Math.random() > 0.5 ? 'bg-black' : 'bg-transparent'}`}></div>
                              ))}
                          </div>
                      </div>
                  </div>
                  <button 
                    onClick={() => { setClockedIn(true); setShowQr(false); }}
                    className="w-full py-3 bg-lumina-base text-white rounded-xl font-bold"
                  >
                      Simulate Scan Success
                  </button>
              </div>
          </div>
      )}
    </div>
  );
};
