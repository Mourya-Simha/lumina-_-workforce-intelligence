import React, { useState, useEffect } from 'react';
import { useApp } from '../services/store';
import { User, Bell, Moon, Languages, LogOut, Edit2, Save, X, Camera, MessageCircle, Send, Calendar, Clock, Phone, BookOpen } from 'lucide-react';
import { DEPARTMENTS } from '../types';

export const Settings = () => {
  const { user, logout, isHindi, toggleLanguage, showToast, updateUserProfile } = useApp();
  
  // Profile Edit State
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
      name: '',
      email: '',
      id: '',
      dept: '',
      avatar: ''
  });

  // Notification Modal State
  const [showNotifyModal, setShowNotifyModal] = useState(false);
  const [notifyData, setNotifyData] = useState({
      date: new Date().toISOString().split('T')[0],
      time: '09:00',
      crNumber: '',
      topic: ''
  });

  // Load current user data when opening edit mode or when user changes
  useEffect(() => {
    if (user) {
        setFormData({
            name: user.name,
            email: user.email,
            id: user.id,
            dept: user.dept,
            avatar: user.avatar || ''
        });
    }
  }, [user]);

  const handleEditClick = () => {
      if (!user) return;
      setFormData({
          name: user.name,
          email: user.email,
          id: user.id,
          dept: user.dept,
          avatar: user.avatar || ''
      });
      setIsEditing(true);
  };

  const handleSave = () => {
      // Basic validation
      if (!formData.name.trim() || !formData.email.trim() || !formData.id.trim() || !formData.dept) {
          showToast("Name, Email, ID and Branch are required", "error");
          return;
      }
      
      updateUserProfile(formData);
      setIsEditing(false);
  };

  const handleCancel = () => {
      setIsEditing(false);
      // Reset form data to current user state
      if (user) {
          setFormData({
              name: user.name,
              email: user.email,
              id: user.id,
              dept: user.dept,
              avatar: user.avatar || ''
          });
      }
  };

  const handleSendNotification = (e: React.FormEvent) => {
      e.preventDefault();
      
      if (!notifyData.crNumber || notifyData.crNumber.length < 10) {
          showToast("Please enter a valid 10-digit mobile number", "error");
          return;
      }

      if (!notifyData.topic.trim()) {
          showToast("Please enter a topic for the test/class", "error");
          return;
      }

      // Construct WhatsApp Message
      // "What's up?" message logic implemented as a schedule update via WhatsApp platform
      const message = `Hello CR, please note the class schedule update.\n\nTopic: ${notifyData.topic}\nDate: ${notifyData.date}\nTime: ${notifyData.time}\n\nRegards,\n${user?.name}`;
      const encodedMessage = encodeURIComponent(message);
      const waUrl = `https://wa.me/${notifyData.crNumber}?text=${encodedMessage}`;

      // Open WhatsApp
      window.open(waUrl, '_blank');
      
      showToast(`Notification sent to CR (${notifyData.crNumber})`, "success");
      setShowNotifyModal(false);
      setNotifyData({ ...notifyData, crNumber: '', topic: '' }); // Reset
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
        <h2 className="text-3xl font-display font-bold text-white">Settings & Preferences</h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Profile Card */}
            <div className={`glass-card p-8 rounded-3xl border ${isEditing ? 'border-lumina-accent shadow-lg shadow-lumina-accent/10' : 'border-white/10'} transition-all`}>
                <div className="flex justify-between items-start mb-6">
                    <h3 className="text-sm font-bold text-lumina-muted uppercase tracking-wider">My Profile</h3>
                    {!isEditing ? (
                        <button 
                            onClick={handleEditClick}
                            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                            title="Edit Profile"
                        >
                            <Edit2 size={16} />
                        </button>
                    ) : (
                        <div className="flex gap-2">
                             <button 
                                onClick={handleCancel}
                                className="p-2 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors"
                                title="Cancel"
                            >
                                <X size={16} />
                            </button>
                            <button 
                                onClick={handleSave}
                                className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
                                title="Save Changes"
                            >
                                <Save size={16} />
                            </button>
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-6 mb-8">
                    <div className="relative group">
                        <img 
                            src={isEditing && formData.avatar ? formData.avatar : user?.avatar} 
                            className="w-24 h-24 rounded-full border-4 border-lumina-surface object-cover" 
                            alt="Avatar" 
                        />
                        {isEditing && (
                            <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                <Camera className="text-white" size={24} />
                            </div>
                        )}
                    </div>
                    <div className="flex-1 w-full">
                        {isEditing ? (
                            <div className="space-y-3">
                                <div>
                                    <label className="text-[10px] uppercase font-bold text-slate-500 mb-1 block">Full Name</label>
                                    <input 
                                        type="text" 
                                        value={formData.name}
                                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                                        className="w-full bg-lumina-base border border-white/20 rounded-lg px-3 py-2 text-white font-bold text-sm focus:border-lumina-accent focus:outline-none"
                                        placeholder="Dr. John Doe"
                                    />
                                </div>
                                <div>
                                    <label className="text-[10px] uppercase font-bold text-slate-500 mb-1 block">Image URL</label>
                                    <input 
                                        type="text" 
                                        value={formData.avatar}
                                        onChange={(e) => setFormData({...formData, avatar: e.target.value})}
                                        className="w-full bg-lumina-base border border-white/20 rounded-lg px-3 py-2 text-slate-300 text-xs focus:border-lumina-accent focus:outline-none"
                                        placeholder="https://..."
                                    />
                                </div>
                            </div>
                        ) : (
                            <div>
                                <h3 className="text-2xl font-bold text-white">{user?.name}</h3>
                                <p className="text-lumina-accent">{user?.role}</p>
                            </div>
                        )}
                    </div>
                </div>

                <div className="space-y-4">
                     <div className="p-4 bg-white/5 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-2">
                        <span className="text-slate-300">Branch / Department</span>
                        {isEditing ? (
                            <select 
                                value={formData.dept}
                                onChange={(e) => setFormData({...formData, dept: e.target.value})}
                                className="bg-lumina-base border border-white/20 rounded-lg px-3 py-1.5 text-white text-sm focus:border-lumina-accent focus:outline-none md:w-2/3"
                            >
                                <option value="">Select Branch</option>
                                {DEPARTMENTS.map(d => (
                                    <option key={d} value={d}>{d}</option>
                                ))}
                                <option value="Administration">Administration</option>
                                <option value="Human Resources">Human Resources</option>
                            </select>
                        ) : (
                            <span className="text-white font-medium text-sm">{user?.dept}</span>
                        )}
                    </div>

                    <div className="p-4 bg-white/5 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-2">
                        <span className="text-slate-300">Email</span>
                        {isEditing ? (
                            <input 
                                type="email" 
                                value={formData.email}
                                onChange={(e) => setFormData({...formData, email: e.target.value})}
                                className="bg-lumina-base border border-white/20 rounded-lg px-3 py-1.5 text-white font-mono text-sm focus:border-lumina-accent focus:outline-none md:text-right md:w-2/3"
                            />
                        ) : (
                            <span className="text-white font-mono text-sm">{user?.email}</span>
                        )}
                    </div>
                    
                    <div className="p-4 bg-white/5 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-2">
                        <span className="text-slate-300">Employee ID</span>
                        {isEditing ? (
                             <input 
                                type="text" 
                                value={formData.id}
                                onChange={(e) => setFormData({...formData, id: e.target.value})}
                                className="bg-lumina-base border border-white/20 rounded-lg px-3 py-1.5 text-white font-mono text-sm focus:border-lumina-accent focus:outline-none md:text-right md:w-2/3"
                            />
                        ) : (
                            <span className="text-white font-mono text-sm">{user?.id}</span>
                        )}
                    </div>
                </div>
            </div>

            {/* Config & Preferences */}
            <div className="space-y-4">
                <div className="glass-card p-6 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-purple-500/20 text-purple-400 rounded-full">
                            <Languages size={20} />
                        </div>
                        <div>
                            <h4 className="font-bold text-white">Language / भाषा</h4>
                            <p className="text-xs text-slate-400">Toggle interface language</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => {
                            toggleLanguage();
                            showToast(isHindi ? "Language switched to English" : "भाषा हिंदी में बदल दी गई", "info");
                        }}
                        className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm font-bold border border-white/10"
                    >
                        {isHindi ? 'Switch to English' : 'हिंदी में बदलें'}
                    </button>
                </div>

                <div className="glass-card p-6 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-blue-500/20 text-blue-400 rounded-full">
                            <Bell size={20} />
                        </div>
                        <div>
                            <h4 className="font-bold text-white">Class Notifications</h4>
                            <p className="text-xs text-slate-400">Alert Class Representative</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => setShowNotifyModal(true)}
                        className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm font-bold border border-white/10 flex items-center gap-2"
                    >
                        <MessageCircle size={16} /> Notify CR
                    </button>
                </div>

                <button 
                    onClick={logout}
                    className="w-full p-4 rounded-xl border border-rose-500/20 text-rose-500 hover:bg-rose-500/10 font-bold flex items-center justify-center gap-2 transition-colors mt-8"
                >
                    <LogOut size={18} /> Sign Out
                </button>
            </div>
        </div>

        {/* Notify CR Modal */}
        {showNotifyModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
                <div className="glass-card w-full max-w-md p-8 rounded-3xl border border-white/20">
                    <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-3">
                             <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl">
                                 <MessageCircle size={24} />
                             </div>
                             <h3 className="text-xl font-bold text-white">Notify Class Rep</h3>
                        </div>
                        <button onClick={() => setShowNotifyModal(false)} className="text-slate-400 hover:text-white transition-colors">
                            <X size={24} />
                        </button>
                    </div>

                    <form onSubmit={handleSendNotification} className="space-y-5">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase mb-2 block flex items-center gap-2">
                                <BookOpen size={12} /> Test / Topic Name
                            </label>
                            <input 
                                type="text" 
                                value={notifyData.topic}
                                onChange={(e) => setNotifyData({...notifyData, topic: e.target.value})}
                                placeholder="e.g. Unit 3 Test: Thermodynamics"
                                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none transition-colors"
                                required
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-2 block flex items-center gap-2">
                                    <Calendar size={12} /> Date
                                </label>
                                <input 
                                    type="date" 
                                    value={notifyData.date}
                                    onChange={(e) => setNotifyData({...notifyData, date: e.target.value})}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none transition-colors"
                                    required
                                />
                            </div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-2 block flex items-center gap-2">
                                    <Clock size={12} /> Time
                                </label>
                                <input 
                                    type="time" 
                                    value={notifyData.time}
                                    onChange={(e) => setNotifyData({...notifyData, time: e.target.value})}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none transition-colors"
                                    required
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase mb-2 block flex items-center gap-2">
                                <Phone size={12} /> CR Mobile Number
                            </label>
                            <input 
                                type="tel" 
                                placeholder="e.g. 9876543210"
                                value={notifyData.crNumber}
                                onChange={(e) => setNotifyData({...notifyData, crNumber: e.target.value.replace(/\D/g,'')})}
                                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:border-lumina-accent outline-none transition-colors font-mono tracking-wider"
                                maxLength={10}
                                required
                            />
                            <p className="text-[10px] text-slate-500 mt-2">
                                * This will open WhatsApp Web to send the message.
                            </p>
                        </div>

                        <button 
                            type="submit"
                            className="w-full py-3.5 bg-emerald-500 text-white font-bold rounded-xl hover:bg-emerald-400 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/20"
                        >
                            <Send size={18} /> Send Schedule Update
                        </button>
                    </form>
                </div>
            </div>
        )}
    </div>
  );
};
